package nc.report.hbbb.test;

import com.ufida.zior.console.ActionHandler;

import nc.bs.framework.test.AbstractTestCase;
import nc.impl.hbbb.backplugin.ReportImportWorkPlugin;
import nc.impl.hbbb.backplugin.ReportMeasureWorkPlugin;
import nc.vo.pub.pa.CurrEnvVO;

public class TestWorkPlugin extends AbstractTestCase{
	
	public void testPlugin(){
//		ActionHandler.exec(ReportImportWorkPlugin.class.getName(),
//				"executeTask", new CurrEnvVO(), true);
	}
	
	public void testMeasurePlugin(){
		ActionHandler.exec(ReportMeasureWorkPlugin.class.getName(),
				"executeTask", new CurrEnvVO(), true);
	}

}

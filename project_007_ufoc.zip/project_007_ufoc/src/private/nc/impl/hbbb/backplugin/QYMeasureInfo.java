package nc.impl.hbbb.backplugin;

import com.ufsoft.table.CellPosition;

import nc.vo.iufo.storecell.IStoreCell;

public class QYMeasureInfo extends AbstractMeasureInfo{

	public QYMeasureInfo(IStoreCell measure, CellPosition measurePoint) {
		super(measure, measurePoint);
		// TODO Auto-generated constructor stub
	}

 
}

package nc.ui.hbbb.hbreport.action;

import nc.vo.hbbb.hbscheme.HBSchemeVO;

import com.ufsoft.iufo.fmtplugin.datastate.CellsModelOperator;
import com.ufsoft.iufo.fmtplugin.formatcore.UfoContextVO;
import com.ufsoft.iuforeport.tableinput.applet.IRepDataParam;
import com.ufsoft.table.CellsModel;

/**
 * �ϲ���������
 * 
 * @version V6.1
 * @author litfb
 */
public class HBReportExportAction extends AbsReportExportAction {

    private static final long serialVersionUID = 3764657684400573028L;

    public HBReportExportAction() {
        super();
        setCode("exportHBRep");
        setBtnName(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0", "01830004-0002")/* @res "�ϲ�����" */);
    }

    @Override
    protected Integer getRepVersion(HBSchemeVO hbSchemeVO) {
        return hbSchemeVO.getVersion();
    }

    @Override
    protected String getRepTypeName() {
        return nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0", "01830004-0002")/* @res "�ϲ�����" */;
    }

    @Override
    protected CellsModel getCellModel(String pk_report, UfoContextVO context, IRepDataParam param) throws Exception {
        CellsModel formatModel = CellsModelOperator.getFormatModelByPKWithDataProcess(context);
        CellsModel cellsModel = CellsModelOperator.fillCellsModelWithDBData(formatModel, context);
        return cellsModel;
    }

}

package nc.ui.hbbb.hbreport.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nc.ui.uif2.factory.AbstractJavaBeanDefinition;

public class hbreport extends AbstractJavaBeanDefinition{
	private Map<String, Object> context = new HashMap();
public nc.vo.iufo.query.IUfoQueryLoginContext getContext(){
 if(context.get("context")!=null)
 return (nc.vo.iufo.query.IUfoQueryLoginContext)context.get("context");
  nc.vo.iufo.query.IUfoQueryLoginContext bean = new nc.vo.iufo.query.IUfoQueryLoginContext();
  context.put("context",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.TemplateContainer getTemplateContainer(){
 if(context.get("templateContainer")!=null)
 return (nc.ui.uif2.editor.TemplateContainer)context.get("templateContainer");
  nc.ui.uif2.editor.TemplateContainer bean = new nc.ui.uif2.editor.TemplateContainer();
  context.put("templateContainer",bean);
  bean.setContext(getContext());
  bean.setNodeKeies(getManagedList0());
  bean.load();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList0(){  List list = new ArrayList();  list.add("repdataquery");  list.add("schemekey");  list.add("investrela");  list.add("copykey");  return list;}

public nc.ui.hbbb.hbreport.model.RepDataFunNodeInitDataListener getInitDataListener(){
 if(context.get("InitDataListener")!=null)
 return (nc.ui.hbbb.hbreport.model.RepDataFunNodeInitDataListener)context.get("InitDataListener");
  nc.ui.hbbb.hbreport.model.RepDataFunNodeInitDataListener bean = new nc.ui.hbbb.hbreport.model.RepDataFunNodeInitDataListener();
  context.put("InitDataListener",bean);
  bean.setQueryExecutor(getQueryExecutor());
  bean.setManager(getModelDataManager());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.model.HBReportDataManager getModelDataManager(){
 if(context.get("modelDataManager")!=null)
 return (nc.ui.hbbb.hbreport.model.HBReportDataManager)context.get("modelDataManager");
  nc.ui.hbbb.hbreport.model.HBReportDataManager bean = new nc.ui.hbbb.hbreport.model.HBReportDataManager();
  context.put("modelDataManager",bean);
  bean.setModel(getModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.model.InvestRelaModelManager getInvestRelaModelManager(){
 if(context.get("investRelaModelManager")!=null)
 return (nc.ui.hbbb.stockinvestrela.model.InvestRelaModelManager)context.get("investRelaModelManager");
  nc.ui.hbbb.stockinvestrela.model.InvestRelaModelManager bean = new nc.ui.hbbb.stockinvestrela.model.InvestRelaModelManager();
  context.put("investRelaModelManager",bean);
  bean.setModel(getInvestrelamodel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.iufo.query.common.model.IUfoBillManageModel getModel(){
 if(context.get("model")!=null)
 return (nc.ui.iufo.query.common.model.IUfoBillManageModel)context.get("model");
  nc.ui.iufo.query.common.model.IUfoBillManageModel bean = new nc.ui.iufo.query.common.model.IUfoBillManageModel();
  context.put("model",bean);
  bean.setContext(getContext());
  bean.setModelFilter(getQueryFilterPanel());
  bean.setBusinessObjectAdapterFactory(getBoAdpaterFactory());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.model.BillManageModel getSchememodel(){
 if(context.get("schememodel")!=null)
 return (nc.ui.uif2.model.BillManageModel)context.get("schememodel");
  nc.ui.uif2.model.BillManageModel bean = new nc.ui.uif2.model.BillManageModel();
  context.put("schememodel",bean);
  bean.setBusinessObjectAdapterFactory(getBoAdpaterFactory());
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.model.BillManageModel getInvestrelamodel(){
 if(context.get("investrelamodel")!=null)
 return (nc.ui.uif2.model.BillManageModel)context.get("investrelamodel");
  nc.ui.uif2.model.BillManageModel bean = new nc.ui.uif2.model.BillManageModel();
  context.put("investrelamodel",bean);
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.model.HBBBSchemeAndQueryPanelMediator getHbSchemeAndQueryPanelMediator(){
 if(context.get("hbSchemeAndQueryPanelMediator")!=null)
 return (nc.ui.hbbb.quickquery.model.HBBBSchemeAndQueryPanelMediator)context.get("hbSchemeAndQueryPanelMediator");
  nc.ui.hbbb.quickquery.model.HBBBSchemeAndQueryPanelMediator bean = new nc.ui.hbbb.quickquery.model.HBBBSchemeAndQueryPanelMediator();
  context.put("hbSchemeAndQueryPanelMediator",bean);
  bean.setHbSchemeRefPanel(getHbSchemeRefPanel());
  bean.setEntrance(getInitEntrance());
  bean.setQueryAction(getQueryAction());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.vo.hbbb.commit.HBBBRepBuziQueryCondVO getQueryCondVo(){
 if(context.get("queryCondVo")!=null)
 return (nc.vo.hbbb.commit.HBBBRepBuziQueryCondVO)context.get("queryCondVo");
  nc.vo.hbbb.commit.HBBBRepBuziQueryCondVO bean = new nc.vo.hbbb.commit.HBBBRepBuziQueryCondVO();
  context.put("queryCondVo",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.model.HBBBQueryChangeListener getQryChangeListener(){
 if(context.get("qryChangeListener")!=null)
 return (nc.ui.hbbb.quickquery.model.HBBBQueryChangeListener)context.get("qryChangeListener");
  nc.ui.hbbb.quickquery.model.HBBBQueryChangeListener bean = new nc.ui.hbbb.quickquery.model.HBBBQueryChangeListener();
  context.put("qryChangeListener",bean);
  bean.setQueryAction(getQueryAction());
  bean.setQueryCondVo(getQueryCondVo());
  bean.setQueryShell(getUserQryPanel());
  bean.setHbSchemeRefPanel(getHbSchemeRefPanel());
  bean.setEntrance(getInitEntrance());
  bean.setResultModel(getModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.model.HBBBTangramInitEntrance getInitEntrance(){
 if(context.get("initEntrance")!=null)
 return (nc.ui.hbbb.quickquery.model.HBBBTangramInitEntrance)context.get("initEntrance");
  nc.ui.hbbb.quickquery.model.HBBBTangramInitEntrance bean = new nc.ui.hbbb.quickquery.model.HBBBTangramInitEntrance();
  context.put("initEntrance",bean);
  bean.setContext(getContext());
  bean.setQueryCondVo(getQueryCondVo());
  bean.setHbSchemeRefPanel(getHbSchemeRefPanel());
  bean.setQueryAction(getQueryAction());
  bean.setHandler(getExceptionHanler());
  bean.init();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.view.HBBBQueryTopPanel getTopPanel(){
 if(context.get("topPanel")!=null)
 return (nc.ui.hbbb.quickquery.view.HBBBQueryTopPanel)context.get("topPanel");
  nc.ui.hbbb.quickquery.view.HBBBQueryTopPanel bean = new nc.ui.hbbb.quickquery.view.HBBBQueryTopPanel();
  context.put("topPanel",bean);
  bean.setContext(getContext());
  bean.setQryChangeListener(getQryChangeListener());
  bean.setHbSchemeListener(getHbSchemeAndQueryPanelMediator());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.view.HBBBSchemeRefPanel getHbSchemeRefPanel(){
 if(context.get("hbSchemeRefPanel")!=null)
 return (nc.ui.hbbb.quickquery.view.HBBBSchemeRefPanel)context.get("hbSchemeRefPanel");
  nc.ui.hbbb.quickquery.view.HBBBSchemeRefPanel bean = new nc.ui.hbbb.quickquery.view.HBBBSchemeRefPanel();
  context.put("hbSchemeRefPanel",bean);
  bean.setValueChangeListener(getHbSchemeAndQueryPanelMediator());
  bean.innerInitUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.model.HBBBQueryAreaShell getUserQryPanel(){
 if(context.get("userQryPanel")!=null)
 return (nc.ui.hbbb.quickquery.model.HBBBQueryAreaShell)context.get("userQryPanel");
  nc.ui.hbbb.quickquery.model.HBBBQueryAreaShell bean = new nc.ui.hbbb.quickquery.model.HBBBQueryAreaShell();
  context.put("userQryPanel",bean);
  bean.setQueryArea(getQueryAction_created_c12c46());
  bean.setQueryExecutor(getQueryExecutor());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.hbbb.quickquery.view.HBBBQueryArea getQueryAction_created_c12c46(){
 if(context.get("queryAction.created#c12c46")!=null)
 return (nc.ui.hbbb.quickquery.view.HBBBQueryArea)context.get("queryAction.created#c12c46");
  nc.ui.hbbb.quickquery.view.HBBBQueryArea bean = getQueryAction().createHbbbQueryArea();
  context.put("queryAction.created#c12c46",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.model.HBReportQueryExecutor getQueryExecutor(){
 if(context.get("queryExecutor")!=null)
 return (nc.ui.hbbb.hbreport.model.HBReportQueryExecutor)context.get("queryExecutor");
  nc.ui.hbbb.hbreport.model.HBReportQueryExecutor bean = new nc.ui.hbbb.hbreport.model.HBReportQueryExecutor();
  context.put("queryExecutor",bean);
  bean.setModel(getModel());
  bean.setEntrance(getInitEntrance());
  bean.setPaginationModel(getPaginationModel());
  bean.setPaginationDelegator(getPaginationDelegator());
  bean.setQueryConfig(getQueryConfig());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBReportQueryAction getQueryAction(){
 if(context.get("queryAction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBReportQueryAction)context.get("queryAction");
  nc.ui.hbbb.hbreport.action.HBReportQueryAction bean = new nc.ui.hbbb.hbreport.action.HBReportQueryAction();
  context.put("queryAction",bean);
  bean.setLoginContext(getContext());
  bean.setExceptionHandler(getExceptionHanler());
  bean.setEntrance(getInitEntrance());
  bean.setShowRepSelectBtn(false);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.quickquery.view.HBBBQueryFilterPanel getQueryFilterPanel(){
 if(context.get("queryFilterPanel")!=null)
 return (nc.ui.hbbb.quickquery.view.HBBBQueryFilterPanel)context.get("queryFilterPanel");
  nc.ui.hbbb.quickquery.view.HBBBQueryFilterPanel bean = new nc.ui.hbbb.quickquery.view.HBBBQueryFilterPanel();
  context.put("queryFilterPanel",bean);
  bean.setQueryAction(getQueryAction());
  bean.setModel(getModel());
  bean.setNorth(getCardLayoutToolbarPanel());
  bean.setQueryConfig(getQueryConfig());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.model.HBReportQueryConfig getQueryConfig(){
 if(context.get("queryConfig")!=null)
 return (nc.ui.hbbb.hbreport.model.HBReportQueryConfig)context.get("queryConfig");
  nc.ui.hbbb.hbreport.model.HBReportQueryConfig bean = new nc.ui.hbbb.hbreport.model.HBReportQueryConfig();
  context.put("queryConfig",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel getCardLayoutToolbarPanel(){
 if(context.get("cardLayoutToolbarPanel")!=null)
 return (nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel)context.get("cardLayoutToolbarPanel");
  nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel bean = new nc.ui.uif2.tangramlayout.CardLayoutToolbarPanel();
  context.put("cardLayoutToolbarPanel",bean);
  bean.setModel(getModel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.BillListView getReportPanel(){
 if(context.get("reportPanel")!=null)
 return (nc.ui.uif2.editor.BillListView)context.get("reportPanel");
  nc.ui.uif2.editor.BillListView bean = new nc.ui.uif2.editor.BillListView();
  context.put("reportPanel",bean);
  bean.setModel(getModel());
  bean.setNodekey("repdataquery");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setSouth(getPaginationBar());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor getSchemeKeyEditor(){
 if(context.get("schemeKeyEditor")!=null)
 return (nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor)context.get("schemeKeyEditor");
  nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor bean = new nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor();
  context.put("schemeKeyEditor",bean);
  bean.setModel(getSchememodel());
  bean.setNodekey("schemekey");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setShowdxscheme("true");
  bean.setOrgPermsion(true);
  bean.setLoadIndividualWhenInit(false);
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor getDiffSchemeKeyEditor(){
 if(context.get("diffSchemeKeyEditor")!=null)
 return (nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor)context.get("diffSchemeKeyEditor");
  nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor bean = new nc.ui.hbbb.qrypanel.schemekey.SchemeKeyEditor();
  context.put("diffSchemeKeyEditor",bean);
  bean.setModel(getSchememodel());
  bean.setNodekey("schemekey");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setShowdxscheme("true");
  bean.setOrgPermsion(true);
  bean.setLoadIndividualWhenInit(false);
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.adjustreport.view.SchemeKeyEditor getCopySchemeKeyEditor(){
 if(context.get("copySchemeKeyEditor")!=null)
 return (nc.ui.hbbb.adjustreport.view.SchemeKeyEditor)context.get("copySchemeKeyEditor");
  nc.ui.hbbb.adjustreport.view.SchemeKeyEditor bean = new nc.ui.hbbb.adjustreport.view.SchemeKeyEditor();
  context.put("copySchemeKeyEditor",bean);
  bean.setModel(getSchememodel());
  bean.setNodekey("copykey");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setShowadjscheme("false");
  bean.setShowdxscheme("false");
  bean.setShowadjtype("false");
  bean.setShowGroupOrg("false");
  bean.setLoadIndividualWhenInit(false);
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.TangramContainer getContainer(){
 if(context.get("container")!=null)
 return (nc.ui.uif2.TangramContainer)context.get("container");
  nc.ui.uif2.TangramContainer bean = new nc.ui.uif2.TangramContainer();
  context.put("container",bean);
  bean.setTangramLayoutRoot(getVSNode_11717bb());
  bean.setActions(getManagedList1());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.VSNode getVSNode_11717bb(){
 if(context.get("nc.ui.uif2.tangramlayout.node.VSNode#11717bb")!=null)
 return (nc.ui.uif2.tangramlayout.node.VSNode)context.get("nc.ui.uif2.tangramlayout.node.VSNode#11717bb");
  nc.ui.uif2.tangramlayout.node.VSNode bean = new nc.ui.uif2.tangramlayout.node.VSNode();
  context.put("nc.ui.uif2.tangramlayout.node.VSNode#11717bb",bean);
  bean.setUp(getCNode_41d52f());
  bean.setDown(getHSNode_1b13521());
  bean.setDividerLocation(30f);
  bean.setShowMode("NoDivider");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_41d52f(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#41d52f")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#41d52f");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#41d52f",bean);
  bean.setComponent(getTopPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.HSNode getHSNode_1b13521(){
 if(context.get("nc.ui.uif2.tangramlayout.node.HSNode#1b13521")!=null)
 return (nc.ui.uif2.tangramlayout.node.HSNode)context.get("nc.ui.uif2.tangramlayout.node.HSNode#1b13521");
  nc.ui.uif2.tangramlayout.node.HSNode bean = new nc.ui.uif2.tangramlayout.node.HSNode();
  context.put("nc.ui.uif2.tangramlayout.node.HSNode#1b13521",bean);
  bean.setLeft(getCNode_133b43());
  bean.setRight(getVSNode_16d9e42());
  bean.setDividerLocation(280f);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_133b43(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#133b43")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#133b43");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#133b43",bean);
  bean.setComponent(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.VSNode getVSNode_16d9e42(){
 if(context.get("nc.ui.uif2.tangramlayout.node.VSNode#16d9e42")!=null)
 return (nc.ui.uif2.tangramlayout.node.VSNode)context.get("nc.ui.uif2.tangramlayout.node.VSNode#16d9e42");
  nc.ui.uif2.tangramlayout.node.VSNode bean = new nc.ui.uif2.tangramlayout.node.VSNode();
  context.put("nc.ui.uif2.tangramlayout.node.VSNode#16d9e42",bean);
  bean.setUp(getCNode_97cc92());
  bean.setDown(getCNode_1f79d23());
  bean.setDividerLocation(80f);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_97cc92(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#97cc92")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#97cc92");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#97cc92",bean);
  bean.setComponent(getQueryFilterPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private nc.ui.uif2.tangramlayout.node.CNode getCNode_1f79d23(){
 if(context.get("nc.ui.uif2.tangramlayout.node.CNode#1f79d23")!=null)
 return (nc.ui.uif2.tangramlayout.node.CNode)context.get("nc.ui.uif2.tangramlayout.node.CNode#1f79d23");
  nc.ui.uif2.tangramlayout.node.CNode bean = new nc.ui.uif2.tangramlayout.node.CNode();
  context.put("nc.ui.uif2.tangramlayout.node.CNode#1f79d23",bean);
  bean.setComponent(getReportPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList1(){  List list = new ArrayList();  list.add(getDeleteaction());  list.add(getCopyRepExeAction());  list.add(getSeperateAction());  list.add(getRefreshaction());  list.add(getSeperateAction());  list.add(getHbaction());  list.add(getDiffaction());  list.add(getHbdatacenteraction());  list.add(getSeperateAction());  list.add(getInvestRelaGroup());  list.add(getSeperateAction());  list.add(getExportactiongroup());  return list;}

public nc.ui.hbbb.hbreport.action.CopyRepExecuteAction getCopyRepExeAction(){
 if(context.get("copyRepExeAction")!=null)
 return (nc.ui.hbbb.hbreport.action.CopyRepExecuteAction)context.get("copyRepExeAction");
  nc.ui.hbbb.hbreport.action.CopyRepExecuteAction bean = new nc.ui.hbbb.hbreport.action.CopyRepExecuteAction();
  context.put("copyRepExeAction",bean);
  bean.setContext(getContext());
  bean.setModel(getModel());
  bean.setSchemeKeyEditor(getCopySchemeKeyEditor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBReportDeleteAction getDeleteaction(){
 if(context.get("deleteaction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBReportDeleteAction)context.get("deleteaction");
  nc.ui.hbbb.hbreport.action.HBReportDeleteAction bean = new nc.ui.hbbb.hbreport.action.HBReportDeleteAction();
  context.put("deleteaction",bean);
  bean.setModel(getModel());
  bean.setQueryExecutor(getQueryExecutor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBReportRefreshAction getRefreshaction(){
 if(context.get("refreshaction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBReportRefreshAction)context.get("refreshaction");
  nc.ui.hbbb.hbreport.action.HBReportRefreshAction bean = new nc.ui.hbbb.hbreport.action.HBReportRefreshAction();
  context.put("refreshaction",bean);
  bean.setModel(getModel());
  bean.setQueryExecutor(getQueryExecutor());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBReportUnionAction getHbaction(){
 if(context.get("hbaction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBReportUnionAction)context.get("hbaction");
  nc.ui.hbbb.hbreport.action.HBReportUnionAction bean = new nc.ui.hbbb.hbreport.action.HBReportUnionAction();
  context.put("hbaction",bean);
  bean.setModel(getModel());
  bean.setSchemeKeyEditor(getSchemeKeyEditor());
  bean.setInvestRelaGraphDelegator(getInvestGraphDelegator());
  bean.setInvestRelaListDelegator(getInvestListDelegator());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.GenDiffReportAction getDiffaction(){
 if(context.get("diffaction")!=null)
 return (nc.ui.hbbb.hbreport.action.GenDiffReportAction)context.get("diffaction");
  nc.ui.hbbb.hbreport.action.GenDiffReportAction bean = new nc.ui.hbbb.hbreport.action.GenDiffReportAction();
  context.put("diffaction",bean);
  bean.setModel(getModel());
  bean.setSchemeKeyEditor(getDiffSchemeKeyEditor());
  bean.setInvestRelaGraphDelegator(getInvestGraphDelegator());
  bean.setInvestRelaListDelegator(getInvestListDelegator());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphShowDelegator getInvestGraphDelegator(){
 if(context.get("investGraphDelegator")!=null)
 return (nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphShowDelegator)context.get("investGraphDelegator");
  nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphShowDelegator bean = new nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphShowDelegator();
  context.put("investGraphDelegator",bean);
  bean.setInvestRelaModel(getInvestrelamodel());
  bean.setViewDisplayer(getViewDisplayer());
  bean.setModelManager(getInvestRelaModelManager());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.action.InvestRelaListShowDelegator getInvestListDelegator(){
 if(context.get("investListDelegator")!=null)
 return (nc.ui.hbbb.stockinvestrela.action.InvestRelaListShowDelegator)context.get("investListDelegator");
  nc.ui.hbbb.stockinvestrela.action.InvestRelaListShowDelegator bean = new nc.ui.hbbb.stockinvestrela.action.InvestRelaListShowDelegator();
  context.put("investListDelegator",bean);
  bean.setDataManager(getInvestRelaModelManager());
  bean.setListView(getInvestRelaListView());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBDataCenterAction getHbdatacenteraction(){
 if(context.get("hbdatacenteraction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBDataCenterAction)context.get("hbdatacenteraction");
  nc.ui.hbbb.hbreport.action.HBDataCenterAction bean = new nc.ui.hbbb.hbreport.action.HBDataCenterAction();
  context.put("hbdatacenteraction",bean);
  bean.setModel(getModel());
  bean.setUserQryPanel(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.MenuAction getExportactiongroup(){
 if(context.get("exportactiongroup")!=null)
 return (nc.funcnode.ui.action.MenuAction)context.get("exportactiongroup");
  nc.funcnode.ui.action.MenuAction bean = new nc.funcnode.ui.action.MenuAction();
  context.put("exportactiongroup",bean);
  bean.setCode("exportactiongroup");
  bean.setName(getI18nFB_116fdba());
  bean.setActions(getManagedList2());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private java.lang.String getI18nFB_116fdba(){
 if(context.get("nc.ui.uif2.I18nFB#116fdba")!=null)
 return (java.lang.String)context.get("nc.ui.uif2.I18nFB#116fdba");
  nc.ui.uif2.I18nFB bean = new nc.ui.uif2.I18nFB();
    context.put("&nc.ui.uif2.I18nFB#116fdba",bean);  bean.setResDir("pub_0");
  bean.setResId("01830008-0119");
  bean.setDefaultValue("����");
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
 try {
     Object product = bean.getObject();
    context.put("nc.ui.uif2.I18nFB#116fdba",product);
     return (java.lang.String)product;
}
catch(Exception e) { throw new RuntimeException(e);}}

private List getManagedList2(){  List list = new ArrayList();  list.add(getExportHBRepAction());  list.add(getExportHBRepDGAction());  list.add(getExportHBDXRepAction());  list.add(getHbSysImpAction());  return list;}

public nc.funcnode.ui.action.GroupAction getInvestRelaGroup(){
 if(context.get("InvestRelaGroup")!=null)
 return (nc.funcnode.ui.action.GroupAction)context.get("InvestRelaGroup");
  nc.funcnode.ui.action.GroupAction bean = new nc.funcnode.ui.action.GroupAction();
  context.put("InvestRelaGroup",bean);
  bean.setCode("investrela");
  bean.setActions(getManagedList3());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

private List getManagedList3(){  List list = new ArrayList();  list.add(getStockInvestViewAction());  list.add(getStockInvestListAction());  return list;}

public nc.ui.hbbb.stockinvestrela.action.InvestRelaListViewAction getStockInvestListAction(){
 if(context.get("stockInvestListAction")!=null)
 return (nc.ui.hbbb.stockinvestrela.action.InvestRelaListViewAction)context.get("stockInvestListAction");
  nc.ui.hbbb.stockinvestrela.action.InvestRelaListViewAction bean = new nc.ui.hbbb.stockinvestrela.action.InvestRelaListViewAction();
  context.put("stockInvestListAction",bean);
  bean.setDataManager(getInvestRelaModelManager());
  bean.setListView(getInvestRelaListView1());
  bean.setInvestRelaQryCondGntr(getInvestQryCondGen());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphViewAction getStockInvestViewAction(){
 if(context.get("stockInvestViewAction")!=null)
 return (nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphViewAction)context.get("stockInvestViewAction");
  nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphViewAction bean = new nc.ui.hbbb.stockinvestrela.action.InvestRelaGraphViewAction();
  context.put("stockInvestViewAction",bean);
  bean.setInvestRelaModel(getInvestrelamodel());
  bean.setViewDisplayer(getViewDisplayer());
  bean.setEnabled(true);
  bean.setInvestRelaQryCondGntr(getInvestQryCondGen());
  bean.setModelManager(getInvestRelaModelManager());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.action.InvestRelaQryCondGenByHBBBQryAreaShell getInvestQryCondGen(){
 if(context.get("investQryCondGen")!=null)
 return (nc.ui.hbbb.stockinvestrela.action.InvestRelaQryCondGenByHBBBQryAreaShell)context.get("investQryCondGen");
  nc.ui.hbbb.stockinvestrela.action.InvestRelaQryCondGenByHBBBQryAreaShell bean = new nc.ui.hbbb.stockinvestrela.action.InvestRelaQryCondGenByHBBBQryAreaShell();
  context.put("investQryCondGen",bean);
  bean.setQueryAreaShell(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.stockinvestrela.view.InvestRelaViewGraphDisplayer getViewDisplayer(){
 if(context.get("viewDisplayer")!=null)
 return (nc.ui.hbbb.stockinvestrela.view.InvestRelaViewGraphDisplayer)context.get("viewDisplayer");
  nc.ui.hbbb.stockinvestrela.view.InvestRelaViewGraphDisplayer bean = new nc.ui.hbbb.stockinvestrela.view.InvestRelaViewGraphDisplayer();
  context.put("viewDisplayer",bean);
  bean.setModel(getInvestrelamodel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.BillListView getInvestRelaListView(){
 if(context.get("investRelaListView")!=null)
 return (nc.ui.uif2.editor.BillListView)context.get("investRelaListView");
  nc.ui.uif2.editor.BillListView bean = new nc.ui.uif2.editor.BillListView();
  context.put("investRelaListView",bean);
  bean.setNodekey("investrela");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setModel(getInvestrelamodel());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.editor.BillListView getInvestRelaListView1(){
 if(context.get("investRelaListView1")!=null)
 return (nc.ui.uif2.editor.BillListView)context.get("investRelaListView1");
  nc.ui.uif2.editor.BillListView bean = new nc.ui.uif2.editor.BillListView();
  context.put("investRelaListView1",bean);
  bean.setNodekey("investrela");
  bean.setTemplateContainer(getTemplateContainer());
  bean.setModel(getInvestrelamodel());
  bean.initUI();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBReportExportAction getExportHBRepAction(){
 if(context.get("exportHBRepAction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBReportExportAction)context.get("exportHBRepAction");
  nc.ui.hbbb.hbreport.action.HBReportExportAction bean = new nc.ui.hbbb.hbreport.action.HBReportExportAction();
  context.put("exportHBRepAction",bean);
  bean.setModel(getModel());
  bean.setUserQryPanel(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.SysImpHBRepAction getHbSysImpAction(){
 if(context.get("hbSysImpAction")!=null)
 return (nc.ui.hbbb.hbreport.action.SysImpHBRepAction)context.get("hbSysImpAction");
  nc.ui.hbbb.hbreport.action.SysImpHBRepAction bean = new nc.ui.hbbb.hbreport.action.SysImpHBRepAction();
  context.put("hbSysImpAction",bean);
  bean.setModel(getModel());
  bean.setUserQryPanel(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBDraftExportAction getExportHBRepDGAction(){
 if(context.get("exportHBRepDGAction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBDraftExportAction)context.get("exportHBRepDGAction");
  nc.ui.hbbb.hbreport.action.HBDraftExportAction bean = new nc.ui.hbbb.hbreport.action.HBDraftExportAction();
  context.put("exportHBRepDGAction",bean);
  bean.setModel(getModel());
  bean.setUserQryPanel(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.hbbb.hbreport.action.HBDXRepExportAction getExportHBDXRepAction(){
 if(context.get("exportHBDXRepAction")!=null)
 return (nc.ui.hbbb.hbreport.action.HBDXRepExportAction)context.get("exportHBDXRepAction");
  nc.ui.hbbb.hbreport.action.HBDXRepExportAction bean = new nc.ui.hbbb.hbreport.action.HBDXRepExportAction();
  context.put("exportHBDXRepAction",bean);
  bean.setModel(getModel());
  bean.setUserQryPanel(getUserQryPanel());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.funcnode.ui.action.SeparatorAction getSeperateAction(){
 if(context.get("seperateAction")!=null)
 return (nc.funcnode.ui.action.SeparatorAction)context.get("seperateAction");
  nc.funcnode.ui.action.SeparatorAction bean = new nc.funcnode.ui.action.SeparatorAction();
  context.put("seperateAction",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.components.pagination.PaginationModel getPaginationModel(){
 if(context.get("paginationModel")!=null)
 return (nc.ui.uif2.components.pagination.PaginationModel)context.get("paginationModel");
  nc.ui.uif2.components.pagination.PaginationModel bean = new nc.ui.uif2.components.pagination.PaginationModel();
  context.put("paginationModel",bean);
  bean.init();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.components.pagination.PaginationBar getPaginationBar(){
 if(context.get("paginationBar")!=null)
 return (nc.ui.uif2.components.pagination.PaginationBar)context.get("paginationBar");
  nc.ui.uif2.components.pagination.PaginationBar bean = new nc.ui.uif2.components.pagination.PaginationBar();
  context.put("paginationBar",bean);
  bean.setPaginationModel(getPaginationModel());
  bean.setContext(getContext());
  bean.registeCallbak();
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.components.pagination.BillManagePaginationDelegator getPaginationDelegator(){
 if(context.get("paginationDelegator")!=null)
 return (nc.ui.uif2.components.pagination.BillManagePaginationDelegator)context.get("paginationDelegator");
  nc.ui.uif2.components.pagination.BillManagePaginationDelegator bean = new nc.ui.uif2.components.pagination.BillManagePaginationDelegator(getModel(),getPaginationModel());  context.put("paginationDelegator",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.vo.bd.meta.BDObjectAdpaterFactory getBoAdpaterFactory(){
 if(context.get("boAdpaterFactory")!=null)
 return (nc.vo.bd.meta.BDObjectAdpaterFactory)context.get("boAdpaterFactory");
  nc.vo.bd.meta.BDObjectAdpaterFactory bean = new nc.vo.bd.meta.BDObjectAdpaterFactory();
  context.put("boAdpaterFactory",bean);
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

public nc.ui.uif2.DefaultExceptionHanler getExceptionHanler(){
 if(context.get("exceptionHanler")!=null)
 return (nc.ui.uif2.DefaultExceptionHanler)context.get("exceptionHanler");
  nc.ui.uif2.DefaultExceptionHanler bean = new nc.ui.uif2.DefaultExceptionHanler();
  context.put("exceptionHanler",bean);
  bean.setContext(getContext());
setBeanFacotryIfBeanFacatoryAware(bean);
invokeInitializingBean(bean);
return bean;
}

}

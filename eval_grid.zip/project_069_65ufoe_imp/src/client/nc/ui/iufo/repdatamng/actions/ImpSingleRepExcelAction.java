
package nc.ui.iufo.repdatamng.actions;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;

import javax.swing.JComponent;

import nc.desktop.ui.WorkbenchEnvironment;
import nc.funcnode.ui.AbstractFunclet;
import nc.impl.iufo.utils.NCLangUtil;
import nc.itf.iufo.individual.IUFOIndividualSettingUtil;
import nc.pub.iufo.cache.IUFOCacheManager;
import nc.ui.iufo.constants.IUfoeActionCode;
import nc.ui.iufo.data.MeasurePubDataBO_Client;
import nc.ui.iufo.input.table.TableInputParam;
import nc.ui.iufo.repdatamng.view.ImpRepExcelDlg;
import nc.ui.iufo.uf2.RmsToRmsVerionPkByPubDataUtil;
import nc.ui.pub.beans.UIDialog;
import nc.ui.uif2.DefaultExceptionHanler;
import nc.ui.uif2.ShowStatusBarMsgUtil;
import nc.vo.iufo.data.IKeyDetailData;
import nc.vo.iufo.data.MeasureDataUtil;
import nc.vo.iufo.data.MeasurePubDataVO;
import nc.vo.iufo.keydef.KeyGroupVO;
import nc.vo.iufo.keydef.KeyVO;
import nc.vo.iufo.query.IUfoQueryInitParam;
import nc.vo.iufo.query.IUfoQueryLoginContext;
import nc.vo.iufo.repdataquery.RepDataQueryResultVO;
import nc.vo.iufo.task.TaskInfoVO;
import nc.vo.iufo.task.TaskVO;
import nc.vo.ml.NCLangRes4VoTransl;

import org.apache.commons.beanutils.BeanUtils;

import com.ufida.iufo.pub.tools.AppDebug;
import com.ufida.zior.console.ActionHandler;
import com.ufsoft.iuforeport.repdatainput.LoginEnvVO;
import com.ufsoft.iuforeport.repdatainput.ufoe.IUfoTableInputActionHandler;
import com.ufsoft.iuforeport.tableinput.applet.IRepDataParam;
import com.ufsoft.iuforeport.tableinput.applet.RepDataParam;

/**
 * �������ݲ�ѯ - ���뵥�� excel
 * @author wuyongc
 * @created at 2012-2-7,����1:25:39
 *
 */
public class ImpSingleRepExcelAction extends ImpExpRepDataAuthBaseAction {

	private static final long serialVersionUID = 4033667931955574221L;
	//delete tianjlc ȫ�ֱ������ܻ������������
//	private static final String IMP_SINGLE_REP = nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-1407")/*@res "���뵥��"*/;

	public ImpSingleRepExcelAction(){
		super();
		setBtnName(NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-1407")/*@res "���뵥��"*/);
		setCode(IUfoeActionCode.REP_IMPORT_SINGLE);
		((DefaultExceptionHanler)exceptionHandler).setErrormsg(NCLangUtil.getStrByID("1820001_0", "01820001-0442")/*@res "����ʧ��!"*/);
	}
	@Override
	public void doAction(ActionEvent e) throws Exception {
		super.doAction(e);
		RepDataQueryResultVO repRequeryDataVO = (RepDataQueryResultVO) getModel().getSelectedData();
        final IRepDataParam param = new RepDataParam();
        param.setAloneID(repRequeryDataVO.getAlone_id());
        param.setReportPK(repRequeryDataVO.getPk_report());
        param.setOperType(TableInputParam.OPERTYPE_REPDATA_INPUT);
        param.setTaskPK(repRequeryDataVO.getPk_task());
        param.setRepMngStructPK(nodeEnv.getCurrMngStuc());
        param.setRepOrgPK(nodeEnv.getCurrOrg());
        param.setCurGroupPK(WorkbenchEnvironment.getInstance().getGroupVO().getPk_group());
        //��������,�����޸�ԭ��������
        final RepDataQueryResultVO repData = new RepDataQueryResultVO();
        BeanUtils.copyProperties(repData, repRequeryDataVO);
        param.setPubData(repData.getPubData());

        String taskPK = getTaskPK();
        TaskInfoVO taskInfo  = IUFOCacheManager.getSingleton().getTaskCache().getTaskInfoByPk(taskPK);
        final TaskVO task  = taskInfo.getTaskVO();


		IUfoQueryInitParam queryParam = ((IUfoQueryLoginContext)getLoginContext()).getInitParam() ;
		RepDataQueryResultVO repDataRs = (RepDataQueryResultVO)getModel().getSelectedData();
		KeyVO[] keys = queryParam.getKeyGroup().getKeys();
		IKeyDetailData keyDetailData = null;
		String[] keyVals = new String[keys.length];
		StringBuilder keywordGroupValue = new StringBuilder("{");
		RepDataQueryResultVO repDataQryResult = new RepDataQueryResultVO();

		BeanUtils.copyProperties(repDataQryResult, repDataRs);

//		String orgName = MultiLangTextUtil.getCurLangText(((IUfoBillManageModel)getModel()).getOrgPkMap().get(repDataQryResult.getPk_org()));

		String strAccSchemePK = task.getPk_accscheme();

		String[] strKeyVals = getKeyVals(keys,repDataQryResult);

//        String rmsVerionPk=RmsToRmsVerionPkByPubDataUtil.getRmsVersionPkByRmsPkAndPubdata(param.getPubData(), param.getRepMngStructPK());
//        param.setRepMngStructPK(rmsVerionPk);
		ImpRepExcelDlg dlg = new ImpRepExcelDlg(getLoginContext(),getRepDataQuery() + "-" + NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-1407")/*@res "���뵥��"*/,strKeyVals,strAccSchemePK,param);



        dlg.gettaskLabel().setText(taskInfo.getTaskVO().getCode()+ " " +  taskInfo.getTaskVO().getChangeName());
        dlg.showModal();


        //TODO


        if(dlg.getResult() == UIDialog.ID_OK){
        	final Object[] objs = dlg.getMultImportInfos();

            if (objs==null)
    			return;
            final JComponent UI = getModel().getContext().getEntranceUI();
    		if (UI instanceof AbstractFunclet) {
    			AbstractFunclet funclet = (AbstractFunclet) UI;
    			funclet.showStatusBarMessage(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("10140udddb",
    					"010140udddb0002")/* @res "���ڽ��к�̨����, ���Ե�..." */);
    			funclet.showProgressBar(true);
    			funclet.lockFuncWidget(true);
    		}
    		ExecutorService executor = getModel().getContext().getExecutor();
    		executor.execute(new Runnable() {
    			@Override
    			public void run() {
    				try {
    					List<Object[]> objects=(List<Object[]>)objs[0];
    					boolean bAutoCal=(Boolean)objs[1];
    					
    					IRepDataParam pm = null;
    					LoginEnvVO loginEnv = getLoginEnvVO();
    					List<Object[]> list = new ArrayList<Object[]>();
    					List<Object> ol = null;
    					for (int i = 0; i < objects.size(); i++) {
    						Object[] op = new Object[5];
    						
    						// ��װ�ؼ������ֵ
    						pm = new RepDataParam();
    						BeanUtils.copyProperties(pm, param);
    						
    						String[] keyVs = ((List<String[]>)objs[2]).get(i);
    						
    						//����
    						pm.setAloneID(MeasureDataUtil.getIufoAloneID(getKeyGroupVO().getKeyGroupPK(), keyVs));
    						pm.getPubData().setAloneID(pm.getAloneID());
    						pm.getPubData().setKeywords(keyVs);
    						
    						repData.setPubData(pm.getPubData());
    						dealMeasurePubdata(repData);
    						
    						op[0] = pm;//TODO
    						op[1] = loginEnv;
    						ol = new ArrayList<Object>();
    						ol.add(objects.get(i));
    						op[2] = ol;
    						op[3] = bAutoCal;
    						//������Ҳ������,�����̨�ٴβ�ѯ����.
    						op[4] = task;
    						list.add(op);
    					}
    					
    					//TODO
    					String[] errMsgs=(String[])ActionHandler.execWithZip(IUfoTableInputActionHandler.class.getName(), "importExcelDataByMultiKeygroupVal",
    							list);
    					getQueryExecutor().reQuery();
    					if (errMsgs.length>0){
    						throw new Exception(Arrays.asList(errMsgs).toString());
    					}else{
    						ShowStatusBarMsgUtil.showStatusBarMsg(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-0848")/*@res "����ɹ���"*/, getModel().getContext());
    					}
    					
    				} catch (Exception e) {
    					if (UI instanceof AbstractFunclet) {
    						AbstractFunclet funclet = (AbstractFunclet) UI;
    						funclet.lockFuncWidget(false);
    						funclet.showProgressBar(false);
    					}
    					AppDebug.debug(e);
    					ShowStatusBarMsgUtil.showErrorMsg(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-0442")/*@res "����ʧ�ܡ�"*/,e.getMessage(), getModel().getContext());
    				} finally {
    					if (UI instanceof AbstractFunclet) {
    						AbstractFunclet funclet = (AbstractFunclet) UI;
    						funclet.lockFuncWidget(false);
    						funclet.showProgressBar(false);
    					}
    				}
    			}
    		});
        }
	}

	private LoginEnvVO getLoginEnvVO(){
		LoginEnvVO loginEnv = new LoginEnvVO();

		loginEnv.setCurLoginDate(WorkbenchEnvironment.getServerTime().toStdString());
		loginEnv.setDataExplore(true);
		loginEnv.setDataSource(IUFOIndividualSettingUtil.getDefaultDataSourceVo());
		loginEnv.setLangCode(WorkbenchEnvironment.getLangCode());
		loginEnv.setLoginUnit(nodeEnv.getCurrOrg());
		loginEnv.setRmsPK(nodeEnv.getCurrMngStuc());
		return loginEnv;
	}

	private KeyGroupVO getKeyGroupVO(){
		IUfoQueryInitParam param = ((IUfoQueryLoginContext)getLoginContext()).getInitParam() ;
		return param.getKeyGroup();
	}

	private void dealMeasurePubdata(RepDataQueryResultVO repRequeryDataVO) throws Exception{
//		if(!repRequeryDataVO.getInputstate().booleanValue()){
			//�����δ¼�룬��ô��Ӧ��pubVO���ܴ��ڿ��ܲ����ڡ����Դ˴���Ҫ�ж�
			MeasurePubDataVO dbMeasurePubData = MeasurePubDataBO_Client.findByKeywords(repRequeryDataVO.getPubData());
			if(dbMeasurePubData == null){
				MeasurePubDataBO_Client.createMeasurePubData(repRequeryDataVO.getPubData());
			}
//		}
	}

	private String[] getKeyVals(KeyVO[] keys,RepDataQueryResultVO repDataQryResult){
		String[] keyVals = new String[keys.length];
		keyVals[0] = repDataQryResult.getPk_org();
		for(int i=1; i<keys.length; i++){//ǰ���Ѿ������˵�λ�ؼ���,����ֱ�Ӵ� �ڶ����ؼ��ֿ�ʼ
			keyVals[i] = repDataQryResult.getKeywordByIndex(i+1);
		}
		return keyVals;
	}
}

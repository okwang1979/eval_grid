package nc.ui.iufo.repdatamng.actions;

public interface SysImpUpdataUI  {
	
	
	
	
	 void upUi(Object... param);

}

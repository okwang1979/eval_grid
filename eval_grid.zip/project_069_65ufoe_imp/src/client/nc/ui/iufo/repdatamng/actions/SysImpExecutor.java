package nc.ui.iufo.repdatamng.actions;

import nc.vo.iufo.repdataquery.RepDataQueryResultVO;

public interface SysImpExecutor {
	
	void runImp(SysImpUpdataUI ui) throws Exception ;

}

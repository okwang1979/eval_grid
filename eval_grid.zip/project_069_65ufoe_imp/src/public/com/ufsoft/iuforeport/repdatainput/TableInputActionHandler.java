package com.ufsoft.iuforeport.repdatainput;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.help.UnsupportedOperationException;

import nc.pub.bi.clusterscheduler.SchedulerUtilities;
import nc.pub.iufo.cache.UFOCacheManager;
import nc.ui.iufo.data.MeasurePubDataBO_Client;
import nc.ui.iufo.dataexchange.MultiSheetImportUtil;
import nc.ui.iufo.dataexchange.RepDataExport;
import nc.ui.iufo.dataexchange.RepDataWithCellsModelExport;
import nc.ui.iufo.dataexchange.TableDataToExcel;
import nc.ui.iufo.input.CSomeParam;
import nc.ui.iufo.input.InputActionUtil;
import nc.ui.iufo.input.InputUtil;
import nc.ui.iufo.input.TableInputOperUtil;
import nc.ui.iufo.input.table.TableInputParam;
import nc.util.iufo.pub.AuditUtil;
import nc.util.iufo.sysinit.UfobIndividualSettingUtil;
import nc.util.iufo.sysinit.UfobSysParamQueryUtil;
import nc.vo.bi.clusterscheduler.ErrorMessage;
import nc.vo.iufo.data.IKeyDetailData;
import nc.vo.iufo.data.MeasurePubDataVO;
import nc.vo.iufo.data.MeasureTraceVO;
import nc.vo.iufo.datasource.DataSourceVO;
import nc.vo.iufo.keydef.KeyGroupVO;
import nc.vo.iufo.keydef.KeyVO;
import nc.vo.iuforeport.rep.ReportVO;
import nc.vo.pub.lang.UFBoolean;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ufida.dataset.Context;
import com.ufida.iufo.pub.tools.AppDebug;
import com.ufsoft.iufo.check.vo.CheckResultVO;
import com.ufsoft.iufo.fmtplugin.datastate.CellsModelOperator;
import com.ufsoft.iufo.fmtplugin.formatcore.IUfoContextKey;
import com.ufsoft.iufo.fmtplugin.formatcore.UfoContextVO;
import com.ufsoft.iufo.fmtplugin.formula.FormulaModel;
import com.ufsoft.iufo.fmtplugin.measure.MeasureModel;
import com.ufsoft.iufo.fmtplugin.service.ReportCalcSrv;
import com.ufsoft.iufo.fmtplugin.service.ReportFormatSrv;
import com.ufsoft.iufo.fmtplugin.storecell.LightStoreCellModel;
import com.ufsoft.iufo.fmtplugin.storecell.StoreCellModel;
import com.ufsoft.iufo.func.excel.text.ImpExpFileNameUtil;
import com.ufsoft.iufo.inputplugin.MeasTraceInfo;
import com.ufsoft.iufo.inputplugin.biz.FontFactory;
import com.ufsoft.iufo.inputplugin.biz.data.ImportExcelDataBizUtil;
import com.ufsoft.iufo.inputplugin.biz.file.ChangeKeywordsData;
import com.ufsoft.iufo.inputplugin.biz.file.ChooseRepData;
import com.ufsoft.iufo.repcalc.RepCalcErrorInfo;
import com.ufsoft.iufo.report.propertyoperate.UFOFormulaEditControl;
import com.ufsoft.iuforeport.tableinput.FormulaTraceUtil;
import com.ufsoft.iuforeport.tableinput.TraceDataResult;
import com.ufsoft.iuforeport.tableinput.applet.FormulaTraceParam;
import com.ufsoft.iuforeport.tableinput.applet.IFormulaParsedDataItem;
import com.ufsoft.iuforeport.tableinput.applet.IFormulaTraceParam;
import com.ufsoft.iuforeport.tableinput.applet.IFormulaTraceValueItem;
import com.ufsoft.iuforeport.tableinput.applet.IRepDataParam;
import com.ufsoft.iuforeport.tableinput.applet.ITraceDataParam;
import com.ufsoft.iuforeport.tableinput.applet.RepDataParam;
import com.ufsoft.iuforeport.tableinput.applet.TableInputException;
import com.ufsoft.script.base.UfoVal;
import com.ufsoft.table.CellPosition;
import com.ufsoft.table.CellsModel;
import com.ufsoft.table.IArea;
import com.ufsoft.table.format.IFormat;

public class TableInputActionHandler implements IUfoContextKey {
	public RepDataOperResultVO performCalc(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerPerformCalc((CellsModel) params[0], (IRepDataParam) params[1], (LoginEnvVO) params[2], ((Boolean) params[3]).booleanValue());
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public RepDataOperResultVO saveRepData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerSaveRepData((CellsModel) params[0], (IRepDataParam) params[1], (LoginEnvVO) params[2]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public RepDataOperResultVO openRepData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerOpenRepData((IRepDataParam) params[0], (LoginEnvVO) params[1], (String) params[2]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public ChooseRepData[] loadTableImportReps(Object param) throws Exception {
		try {
			return innerLoadTableImportReps((IRepDataParam) param);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public ChangeKeywordsData[] getChangeKeywordsData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerGetChangeKeywordsData((IRepDataParam) params[0], (LoginEnvVO) params[1]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public ChangeKeywordsData[] getDataExploreChangeKeywordsData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return TableInputOperUtil.geneChangeKeywordsDatas((KeyVO[]) params[0], (String[]) params[1], (Boolean) params[2], (String) params[3]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	@Deprecated
	// ����֧��,����ɾ��
	public Object importIUFOData(Object param) throws Exception {
		// Object[] params=(Object[])param;
		// return
		// innerImportIUFOData((IRepDataParam)params[0],(LoginEnvVO)params[1],(String[])params[2]);
		throw new UnsupportedOperationException();
	}

	public TraceDataResult traceData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerTraceData((IRepDataParam) params[0], (LoginEnvVO) params[1], (CellsModel) params[2], (ITraceDataParam) params[3], ((Integer) params[4]).intValue());
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public byte[] export2Excel(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerExport2Excel((IRepDataParam) params[0], (LoginEnvVO) params[1], (CellsModel) params[2], (String) params[3], (String) params[4]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}
	
	/**
	 * �����Ƿ���ʾ0ֵ�ֶ�
	 * 
	 * @creator tianjlc at 2015-3-19 ����8:39:40
	 * @param param
	 * @return
	 * @throws Exception
	 * @return byte[]
	 */
	public byte[] export2ExcelWithShowZero(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerExport2ExcelWithShowZero((IRepDataParam) params[0], (LoginEnvVO) params[1], (CellsModel) params[2], (String) params[3], (String) params[4],(boolean)params[5]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public MeasurePubDataVO submitKeywordData(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerSubmitKeywordData((IRepDataParam) params[0], (LoginEnvVO) params[1], (KeyVO[]) params[2], (String[]) params[3]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public Object[] getMeasTraceContext(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerGetMeasTraceContext((MeasTraceInfo) params[0], (Boolean) params[1]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	public RepDataOperResultVO importExcelData(Object param) throws Exception {
		Object[] params = (Object[]) param;
		return innerImportExcelData((IRepDataParam) params[0], (LoginEnvVO) params[1], (List<Object[]>) params[2], ((Boolean) params[3]).booleanValue());
	}

	protected Object[] innerGetMeasTraceContext(MeasTraceInfo measTraceInfo, boolean bNeedCreateMainBoard) throws Exception {
		Context context = new Context();
		MeasurePubDataVO pubData = TableInputHandlerHelper.getTraceMeasPubData(measTraceInfo);
		context.setAttribute(MEASURE_PUB_DATA_VO, pubData);

		if (bNeedCreateMainBoard) {
			context.setAttribute(CUR_REPORG_PK, measTraceInfo.getStrOrgPK());
		}
		return new Object[] { context, measTraceInfo };
	}

	public byte[] innerExport2Excel(IRepDataParam param, LoginEnvVO loginEnv, CellsModel cellsModel, String sheetName, String filepath) throws Exception {
		
		return innerExport2ExcelWithShowZero(param, loginEnv, cellsModel, sheetName, filepath, false);
	}
	/**
	 * �����Ƿ���ʾ0ֵ�ֶ�
	 * 
	 * @creator tianjlc at 2015-3-18 ����5:01:58
	 * @param param
	 * @param loginEnv
	 * @param cellsModel
	 * @param sheetName
	 * @param filepath
	 * @param bShowZero
	 * @return
	 * @throws Exception
	 * @return byte[]
	 */
	public byte[] innerExport2ExcelWithShowZero(IRepDataParam param, LoginEnvVO loginEnv, CellsModel cellsModel, String sheetName, String filepath,boolean bShowZero) throws Exception {
		String strAloneID4ExportExcel = param.getAloneID();
		UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);
		RepDataWithCellsModelExport exportObj = new RepDataWithCellsModelExport(context, cellsModel);

		String strReportPK4ExportExcel = param.getReportPK();
		CSomeParam cSomeParam = new CSomeParam();
		cSomeParam.setAloneId(strAloneID4ExportExcel);
		cSomeParam.setRepId(strReportPK4ExportExcel);
		cSomeParam.setUserID(param.getOperUserPK());
		MeasurePubDataVO pubData = param.getPubData();
		cSomeParam.setUnitId(pubData.getUnitPK());
		((RepDataExport) exportObj).setParam(cSomeParam);
		((RepDataExport) exportObj).setLoginDate(loginEnv.getCurLoginDate());
		// editor tianjlc 2015-03-18 ���õ���������Excel�ļ��Ƿ���ʾ0ֵ
		((RepDataExport) exportObj).setShowZero(bShowZero);

		Workbook workBook = null;
		if (ImpExpFileNameUtil.isExcel2003(filepath)) {
			workBook = new HSSFWorkbook();
		} else if (ImpExpFileNameUtil.isExcel2007(filepath)) {
			workBook = new org.apache.poi.xssf.streaming.SXSSFWorkbook(500);
		}
		FontFactory fontFactory = new FontFactory(workBook);
		if (StringUtils.isEmpty(sheetName)) {
			sheetName = "sheet1";
		}
		exportObj.setSheetName(sheetName);
		TableDataToExcel.translate(exportObj, workBook, fontFactory);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		workBook.write(outputStream);
		outputStream.flush();

		byte[] bytes = outputStream.toByteArray();
		outputStream.close();
		return bytes;
	}
	/**
	 * ��ʽ׷�ټ�������ֵ
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public IFormulaTraceValueItem getCalulatedValue(Object param) throws Exception {
		Object[] params = (Object[]) param;

		if (params[0] instanceof LoginEnvVO) {
			LoginEnvVO loginEnv = (LoginEnvVO) params[0];
			IRepDataParam repParam = (IRepDataParam) params[1];

			UfoContextVO context = TableInputHandlerHelper.getContextVO(repParam, loginEnv);
			ReportFormatSrv repFormatSrv = new ReportFormatSrv(context, true);
			CellsModel cellsModel = repFormatSrv.getCellsModel();

			params[0] = cellsModel;
		}

		CellsModel model = (CellsModel) params[0];
		IRepDataParam repDataParam = (IRepDataParam) params[1];
		LoginEnvVO loginEnv = (LoginEnvVO) params[2];
		IFormulaParsedDataItem formulaParsedDataItem = (IFormulaParsedDataItem) params[3];
		IFormulaTraceParam formulaTraceParam = new FormulaTraceParam();
		formulaTraceParam.setParsedDataItem(formulaParsedDataItem);
		UfoContextVO context = TableInputHandlerHelper.getContextVO(repDataParam, loginEnv);
		if (repDataParam.isHBBBData()) {
			context.setAttribute(IS_HBBBDATA, true);
		}

		ReportCalcSrv reportCalcSrv = new ReportCalcSrv(context, model);

		// ����ֵ����ʱС��λ���������⣬��Ҫȡ��׷��λ�õĸ�ʽ��Ϣ
		IFormat format = null;
		if (params != null && params.length > 4 && params[4] instanceof MeasureTraceVO) {
			MeasureTraceVO traceVO = (MeasureTraceVO) params[4];
			if (formulaParsedDataItem.isTraceSelf()) {
				// ����Ǳ���׷�٣����õ�ǰ������ģ��ȡָ���Ӧλ�õĸ�ʽ
				format = getTracePosFormat(model, loginEnv, traceVO, context, formulaParsedDataItem);
			} else {
				// ���������׷�٣���Ҫ��������������ģ�ͣ����Ӹ�����ģ���л�ȡ׷��λ�õĸ�ʽ
				format = getTracePosFormat(null, loginEnv, traceVO, context, formulaParsedDataItem);
			}
		} else {
			// ���ݼ�����׷�٣�ȡ׷��λ�õĸ�ʽ
			CellPosition cell = formulaParsedDataItem.getAbsCell();
			if (cell != null) {
				format = model.getCellFormat(cell);
			}
		}

		// �Թ�ʽ����ִ�м���
		UfoVal[] values = reportCalcSrv.calcFormula(formulaTraceParam.getParsedDataItem());
		// �Լ����������ض��ĸ�ʽת��
		return FormulaTraceUtil.getFormulaTraceValueItem(reportCalcSrv, values, formulaTraceParam.getParsedDataItem(), format);
	}

	/**
	 * ������ģ���л�ȡ��Ӧλ�õĸ�ʽ��Ϣ
	 * 
	 * ׷�ٱ������ݣ��ӱ�������ģ����ȡ��׷��λ�õĸ�ʽ�� ׷���������ݣ���Ҫȡ������������ģ�ͣ����Ӹ�����ģ����ȡ׷��λ�õĸ�ʽ��
	 * 
	 * @param params
	 * @param cell
	 *            ����̬��λ��
	 * @return
	 * @throws Exception
	 */
	private IFormat getTracePosFormat(CellsModel cellsModel, LoginEnvVO loginEnv, MeasureTraceVO traceVO, UfoContextVO context, IFormulaParsedDataItem formulaParsedDataItem) throws Exception {

		IArea[] areas = formulaParsedDataItem == null ? null : formulaParsedDataItem.getTracedPos();

		if (cellsModel == null && context != null) {
			// ����׷�ٵ����ݣ���ȡ׷�����ݵ�MeasurePubDataVO
			MeasTraceInfo info = new MeasTraceInfo(traceVO.getMeasurePK(), traceVO.getKeyvalues(), traceVO.getReportpk(), traceVO.getAloneID(), traceVO.getAccSchemaPK(), true);
			MeasurePubDataVO pubData = TableInputHandlerHelper.getTraceMeasPubData(info);

			if (pubData == null) {
				return null;
			}
			// ��ȡ׷�����ݱ����Ĳ���
			RepDataParam traceParam = getRepDataParam(context, traceVO);
			traceParam.setPubData(pubData);

			// ����׷�����ݱ����Ĳ������������Ļ�����Ϣ
			UfoContextVO traceContext = TableInputHandlerHelper.getContextVO(traceParam, loginEnv);

			// ��ȡ׷�����ݱ���ģ��
			ReportFormatSrv repFormatSrv = new ReportFormatSrv(traceContext, true);
			cellsModel = repFormatSrv.getCellsModel();
		}

		if (areas == null || areas.length < 1) {

			if (formulaParsedDataItem != null) {
				String strReportPK = traceVO.getReportpk();
				String strMeasurePK = traceVO.getMeasurePK();

				IKeyDetailData[] keDetails = traceVO.getKeyvalues();
				String[] strKeyVals = new String[keDetails.length];
				for (int i = 0; i < keDetails.length; i++) {
					strKeyVals[i] = keDetails[i].getValue();
				}

				if (cellsModel != null) {
					areas = calMeasureTracedPos(strReportPK, cellsModel, strMeasurePK, strKeyVals);
				}
			}
		}

		if (cellsModel != null && areas != null && areas.length > 0 && areas[0] != null) {
			// ����ģ����ȡ����Ӧλ�õĸ�ʽ��Ϣ
			return cellsModel.getCellFormat(areas[0].getStart());
		}

		return null;
	}

	private RepDataParam getRepDataParam(UfoContextVO context, MeasureTraceVO traceVO) {
		RepDataParam repDataParam = new RepDataParam();
		repDataParam.setAloneID(traceVO.getAloneID());
		repDataParam.setReportPK(traceVO.getReportpk());
		repDataParam.setTaskPK(null);
		repDataParam.setOperType(TableInputParam.OPERTYPE_REPDATA_INPUT);
		repDataParam.setOperUserPK((String) context.getAttribute(IUfoContextKey.CUR_USER_ID));
		repDataParam.setRepOrgPK((String) context.getAttribute(IUfoContextKey.CUR_REPORG_PK));
		repDataParam.setCurGroupPK((String) context.getAttribute(IUfoContextKey.CUR_GROUP_PK));
		return repDataParam;
	}

	public static IArea[] calMeasureTracedPos(String strReportPK, CellsModel cellsModel, String strMeasurePK, String[] strKeyVals) {

		IArea[] curTracedPos = null;

		CellPosition mesureCell = CellsModelOperator.getMeasureDataPos(strReportPK, cellsModel, strMeasurePK, strKeyVals);
		curTracedPos = new IArea[] { mesureCell };
		return curTracedPos;
	}

	/**
	 * @i18n miufohbbb00170=��������ʧ��:
	 */
	private RepDataOperResultVO innerPerformCalc(CellsModel cellsModel, IRepDataParam param, LoginEnvVO loginEnv, boolean bAreaCal) throws TableInputException {
		try {
			// Ϊ�˼�������,�ͻ��˴�������ģ���в�������ʽģ��,ָ��ģ��,�洢��Ԫģ��,��Ҫ�ڴ˼���
			putExtModel(cellsModel, param);

			UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);

			InputUtil.doCalPrepare(param.getOperUserPK(), loginEnv.getCurLoginDate(), context);

			TableInputLocalCalThread thread = new TableInputLocalCalThread(context, cellsModel, bAreaCal, param);
			// thread.setDiCalcExecutor(getDICalcExecutor(cellsModel));
			String strJobId = SchedulerUtilities.addJob(thread);

			RepDataOperResultVO resultVO = new RepDataOperResultVO();
			resultVO.setThreadID(strJobId);
			resultVO.setLastCalcTime(AuditUtil.getCurrentTime());
			return resultVO;
		} catch (Exception e) {
			AppDebug.debug(e);
			throw new TableInputException(e.getMessage());
		}
	}

	protected void putExtModel(CellsModel cellsModel, IRepDataParam param) {
		String strReportPK = param.getReportPK();
		CellsModel fmtModel = UFOCacheManager.getSingleton().getRepFormatCache().getUfoTableFormatModel(strReportPK);
		if (fmtModel != null) {
			cellsModel.putExtProp(FormulaModel.class.getName(), FormulaModel.getInstance(fmtModel));
			cellsModel.putExtProp(MeasureModel.class.getName(), MeasureModel.getInstance(fmtModel));
			cellsModel.putExtProp(StoreCellModel.class.getName(), StoreCellModel.getInstance(fmtModel));
			cellsModel.putExtProp(LightStoreCellModel.class.getName(), LightStoreCellModel.getInstance(fmtModel));
		}
	}

	/**
	 * �������ݲ�ѯ�еļ���ִ�д˷�������
	 * 
	 * @create by liuchuna at 2011-11-3,����02:56:57
	 * 
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public RepDataOperResultVO performCalc2(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;

			CellsModel cellsModel = (CellsModel) params[0];
			UfoContextVO context = (UfoContextVO) params[1];
			IRepDataParam repParam = (IRepDataParam) params[2];
			boolean bAreaCal = ((Boolean) params[3]).booleanValue();

			// Ϊ�˼�������,�ͻ��˴�������ģ���в�������ʽģ��,ָ��ģ��,�洢��Ԫģ��,��Ҫ�ڴ˼���
			putExtModel(cellsModel, repParam);

			TableInputLocalCalThread thread = new TableInputLocalCalThread(context, cellsModel, bAreaCal, repParam);
			// thread.setDiCalcExecutor(getDICalcExecutor(cellsModel));
			String strJobId = SchedulerUtilities.addJob(thread);

			RepDataOperResultVO resultVO = new RepDataOperResultVO();
			resultVO.setThreadID(strJobId);
			return resultVO;
		} catch (Exception e) {
			AppDebug.debug(e);
			throw new TableInputException(e.getMessage());
		}
	}

	/**
	 * @i18n miufohbbb00171=��������ʧ��:
	 */
	private RepDataOperResultVO innerSaveRepData(CellsModel cellsModel, IRepDataParam param, LoginEnvVO loginEnv) throws TableInputException {
		try {
			UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv, true);
			return innerDoSaveRepData(cellsModel, context, param);
		} catch (TableInputException e) {
			throw e;
		} catch (Exception e) {
			AppDebug.debug(e);
			throw new TableInputException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1413007_0", "01413007-0956")/*
																															 * @
																															 * res
																															 * "��������ʧ��:"
																															 */+ e.getMessage());
		}
	}

	/**
	 * ע��,�˷���Ϊ�˽�����������,ȥ����ģ���еĹ�ʽģ��,ָ��ģ��,�洢��Ԫģ��
	 * 
	 * @create by liuchuna at 2011-11-10,����04:53:33
	 * 
	 * @param threadID
	 * @return
	 * @throws TableInputException
	 */
	public RepDataOperResultVO reCalcRepData(Object threadID) throws TableInputException {
		try {
			String strThreadID = (String) threadID;
			Object objInfo = SchedulerUtilities.getTaskResultData(strThreadID);
			if (objInfo == null) {
				RepDataOperResultVO result = new RepDataOperResultVO();
				result.setThreadID(strThreadID);
				result.setLastCalcTime(AuditUtil.getCurrentTime());
				return result;
			}

			if (objInfo instanceof RepCalcErrorInfo) {
				throw new TableInputException(((RepCalcErrorInfo) objInfo).getErrors());
			}

			if (objInfo instanceof ErrorMessage) {
				throw new TableInputException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1413007_0", "01413007-0957")/*
																																 * @
																																 * res
																																 * "����ʧ�ܣ�"
																																 */);
			}

			CalThreadInfo info = (CalThreadInfo) objInfo;

			if (info.getException() != null)
				throw info.getException();

			// ȥ����ʽģ��,ָ��ģ��,�洢��Ԫģ��
			CellsModel model = info.getOperResult().getCellsModel();
			removeFiexedAttr(model);

			info.getOperResult().setLastCalcTime(AuditUtil.getCurrentTime());

			return info.getOperResult();
		} catch (TableInputException e) {
			throw e;
		} catch (Exception e) {
			AppDebug.error(e);
			throw new TableInputException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1413007_0", "01413007-0958")/*
																															 * @
																															 * res
																															 * "ȡ�ü���������:"
																															 */+ e.getMessage());
		}
	}

	protected void removeFiexedAttr(CellsModel model) {
		model.getExtProps().remove(FormulaModel.class.getName());
		model.getExtProps().remove(MeasureModel.class.getName());
		model.getExtProps().remove(StoreCellModel.class.getName());
		model.getExtProps().remove(LightStoreCellModel.class.getName());
	}

	protected RepDataOperResultVO innerDoSaveRepData(CellsModel cellsModel, UfoContextVO context, IRepDataParam param) throws Exception {
		try {
			putExtModel(cellsModel, param);

			boolean warnPass = true;
			CellsModel dataModel = cellsModel;
			ReportFormatSrv reportFormatSrv = new ReportFormatSrv(context, dataModel);
			reportFormatSrv.saveReportData();

			RepDataOperResultVO resultVO = new RepDataOperResultVO();

			resultVO.setCellsModel(cellsModel);
			resultVO.setOperSuccess(true);

			// ȡ�ø��Ի����ĵ� �Ƿ��Զ���� ����
			UFBoolean ufboolean = UfobIndividualSettingUtil.getAutoCheck();
			// ���û�и��Ի������Ƿ��Զ����û������ �� ȡϵͳ����������ã�����ȡ���Ի����ĵ��Զ��������
			// boolean autoCheck = ufboolean &&
			// UfobSysParamQueryUtil.getAutoCheck()) ||
			// ufboolean.booleanValue();

			boolean autoCheck = (ufboolean == null && UfobSysParamQueryUtil.getAutoCheck()) || (ufboolean != null && ufboolean.booleanValue());
			// ����ϵͳ�������ý����Զ����(���������˹�ʽ�Ļ�)
			if (autoCheck && InputActionUtil.isExistRepCheckFormulas(param.getReportPK())) {
				// ���б�����˲�������˽��
				CheckResultVO result = TableInputHandlerHelper.doCheckInRep(context, cellsModel, true, warnPass);
				result.setOrgId(param.getRepOrgPK());
				resultVO.setCheckResult(result);
			}
			removeFiexedAttr(cellsModel);
			return resultVO;
		} finally {
		}
	}

	public RepDataOperResultVO innerOpenRepData(IRepDataParam param, LoginEnvVO loginEnv, String strBalCondPK) throws Exception {
		try {
			return innerOpenRepData(param, loginEnv, strBalCondPK, UfoContextVO.RIGHT_DATA_WRITE);
		} finally {
		}
	}

	protected RepDataOperResultVO innerOpenRepData(IRepDataParam param, LoginEnvVO loginEnv, String strBalCondPK, int iDataRight) throws Exception {
		try {
			UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);
			//

			ReportFormatSrv repFormatSrv = new ReportFormatSrv(context, true);
			CellsModel cellsModel = repFormatSrv.getCellsModel();

			RepDataOperResultVO result = new RepDataOperResultVO();
			result.setCellsModel(cellsModel);
			result.setMenuState(TableInputHandlerHelper.getMenuStateData(context, param, loginEnv, iDataRight));

			boolean bIsCanInput = UFOFormulaEditControl.isFormulaEdit(param.getReportPK());
			result.setFmlCanInput(bIsCanInput);

			return result;
		} finally {
		}
	}

	public ChooseRepData[] innerLoadTableImportReps(IRepDataParam param) throws Exception {
		try {
			ReportVO report = UFOCacheManager.getSingleton().getReportCache().getByPK(param.getReportPK());
			return TableInputHandlerHelper.geneChooseRepDatas(new ReportVO[] { report });
		} finally {
		}
	}

	public RepDataOperResultVO innerImportExcelData(IRepDataParam param, LoginEnvVO loginEnv, List<Object[]> listImportInfos, boolean isAutoCalc) throws Exception {
		try {
			UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);

			DataSourceVO dataSource = loginEnv.getDataSource();
			MeasurePubDataVO pubdataVo = context.getPubDataVO();

			// ����Ի��������Ƿ��Զ�����ѡ��˴���ʱ����Ϊ�Զ����� chxw 2007-09-26
			MultiSheetImportUtil importUtil = ImportExcelDataBizUtil.getImportUtilBase(param.getReportPK(), null, dataSource, pubdataVo, param.getRepOrgPK(), param.getRepMngStructPK(), param.getCurGroupPK(), isAutoCalc, loginEnv.getCurLoginDate());

			// ������Excel׼��������Ϣ(CellsModel),���뵽���ݿ�
			boolean isNeedSave = true;
			ImportExcelDataBizUtil.processImportData(importUtil, listImportInfos, isNeedSave);

			ReportFormatSrv repFormatSrv = new ReportFormatSrv(context, true);
			CellsModel cellsModel = repFormatSrv.getCellsModel();

			RepDataOperResultVO result = new RepDataOperResultVO();
			result.setCellsModel(cellsModel);

			return result;
		} finally {
		}
	}

	public ChangeKeywordsData[] innerGetChangeKeywordsData(IRepDataParam param, LoginEnvVO loginEnv) throws Exception {
		// 1,�õ��ؼ����������
		ReportVO report = UFOCacheManager.getSingleton().getReportCache().getByPK(param.getReportPK());
		KeyGroupVO keyGroup = UFOCacheManager.getSingleton().getKeyGroupCache().getByPK(report.getPk_key_comb());
		KeyVO[] keyVOs = keyGroup.getKeys();
		// 2,�õ��ؼ��ֵĳ�ʼֵ
		String[] keyInitValues = TableInputHandlerHelper.getKeyValues(keyVOs, param, loginEnv);
		// #�õ��л��ؼ��ֵĽ�����ʾ��Ҫ�����ݶ���
		return TableInputHandlerHelper.geneChangeKeywordsDatas(keyVOs, keyInitValues, param.isHBBBData(), param.getRepOrgPK());
	}

	/**
	 * @i18n miufo01234=���ܵ��뵱ǰ�ؼ�����ϵ�����
	 */
	@Deprecated
	public CellsModel innerImportIUFOData(IRepDataParam param, LoginEnvVO loginEnv, String[] strKeyVals) throws Exception {
		throw new UnsupportedOperationException();
		/*
		 * try{ //��ñ������ݵ�AloneID ReportVO
		 * report=UFOCacheManager.getSingleton().getReportCache
		 * ().getByPK(param.getReportPK()); KeyGroupVO
		 * keyGroup=UFOCacheManager.getSingleton
		 * ().getKeyGroupCache().getByPK(report.getPk_key_comb()); String
		 * strImportAloneID =
		 * TableInputHandlerHelper.doGetNewAloneID(param,loginEnv
		 * ,keyGroup.getKeys(),strKeyVals); UfoContextVO
		 * context=TableInputHandlerHelper.getContextVO(param,loginEnv);
		 * 
		 * String strCurAloneID=param.getAloneID();
		 * //���Ҫ����Ĺؼ��������뵱ǰ�ؼ���������ͬ������������ʾ if(strImportAloneID != null &&
		 * strImportAloneID.equals(strCurAloneID)){ throw new
		 * TableInputException
		 * (nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID
		 * ("1413007_0","01413007-0959")@res "���ܵ��뵱ǰ�ؼ�����ϵ�����"); //"�ؼ������" }
		 * else{ // MeasurePubDataVO
		 * curPubData=MeasurePubDataBO_Client.findByAloneID
		 * (report.getPk_key_comb(),strCurAloneID);
		 * MeasurePubDataBO_Client.getAloneID(param.getPubData());
		 * MeasurePubDataVO curPubData = param.getPubData();
		 * 
		 * MeasurePubDataVO
		 * newPubData=MeasurePubDataBO_Client.findByAloneID(report
		 * .getPk_key_comb(),strImportAloneID);
		 * curPubData.setAccSchemePK(param.getPubData().getAccSchemePK());
		 * newPubData.setAccSchemePK(param.getPubData().getAccSchemePK());
		 * context.setAttribute(MEASURE_PUB_DATA_VO, newPubData); CellsModel
		 * importCellsModel = loadCellsModel(context);
		 * context.setAttribute(MEASURE_PUB_DATA_VO, curPubData);
		 * //�޸�cellsModel�Ĺؼ���Ϊԭ���Ĺؼ���ֵ CellsModel fmtModel =
		 * DynAreaUtil.getDataModelWithExModel(importCellsModel);
		 * MeasurePubDataUtil.initMeasurePubDataKeyData(new
		 * MeasurePubDataVO[]{curPubData});
		 * CellsModelOperator.setMainKeyData(fmtModel, importCellsModel,
		 * curPubData);
		 * 
		 * 
		 * return importCellsModel; } }finally{ }
		 */
	}

	public MeasurePubDataVO innerSubmitKeywordData(IRepDataParam param, LoginEnvVO loginEnv, KeyVO[] keys, String[] strKeyVals) throws Exception {
		try {
			ReportVO report = UFOCacheManager.getSingleton().getReportCache().getByPK(param.getReportPK());
			String strAloneID = TableInputHandlerHelper.doGetNewAloneID(param, loginEnv, keys, strKeyVals);
			return MeasurePubDataBO_Client.findByAloneID(report.getPk_key_comb(), strAloneID);
		} finally {
		}
	}

	public TraceDataResult innerTraceData(IRepDataParam param, LoginEnvVO loginEnv, CellsModel cellsModel, ITraceDataParam traceParam, int iPort) throws Exception {
		try {
			UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);
			ReportFormatSrv reportFormatSrv = new ReportFormatSrv(context, cellsModel);
			return TableInputHandlerHelper.loadTraceDatas(param.getTaskPK(), reportFormatSrv, traceParam, loginEnv, iPort, false);
		} finally {
		}
	}

	public String exportData2Html(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerExportData2Html((IRepDataParam) params[0], (LoginEnvVO) params[1]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}

	public String innerExportData2Html(IRepDataParam param, LoginEnvVO loginEnv) throws Exception {
		// String
		// strPrevModule=LogModuleControler.switch2LogByAloneID(param.getAloneID());
		// try{
		// UfoTableUtil ufoTableUtil =
		// TableToHtmlUtil.getUfoTableUtil(param.getRepOrgPK(),param.getTaskPK(),param.getReportPK(),param.getAloneID());
		// StringWriter strWriter = new StringWriter();
		// ufoTableUtil.setUserInfo(UFOCacheManager.getSingleton().getUserCache().getUserById(param.getOperUserPK()));
		//
		// TableToHtmlUtil.genTableHtmlWriter(strWriter,ufoTableUtil);
		// return strWriter.toString();
		// }finally{
		// LogModuleControler.resetUnitLog(strPrevModule);
		// }
		// TODO
		return "";
	}

	protected CellsModel loadCellsModel(UfoContextVO context) throws Exception {
		ReportFormatSrv repFormatSrv = new ReportFormatSrv(context, true);
		return repFormatSrv.getCellsModel();
	}

}

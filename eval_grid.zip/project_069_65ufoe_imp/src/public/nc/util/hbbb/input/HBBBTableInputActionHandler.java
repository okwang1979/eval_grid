package nc.util.hbbb.input;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import nc.bs.framework.common.NCLocator;
import nc.bs.hbbb.project.ProjectSynchronize;
import nc.impl.iufo.utils.MultiLangTextUtil;
import nc.itf.hbbb.hbrepstru.HBRepStruUtil;
import nc.itf.iufo.commit.ICommitManageService;
import nc.itf.iufo.commit.ICommitQueryService;
import nc.itf.org.IOrgUnitQryService;
import nc.itf.uap.IUAPQueryBS;
import nc.jdbc.framework.SQLParameter;
import nc.pub.iufo.cache.ReportCache;
import nc.pub.iufo.cache.UFOCacheManager;
import nc.pubitf.bbd.CurrtypeQuery;
import nc.pubitf.bd.accessor.GeneralAccessorFactory;
import nc.pubitf.bd.accessor.IGeneralAccessor;
import nc.ui.iufo.balance.BalanceBO_Client;
import nc.ui.iufo.data.MeasurePubDataBO_Client;
import nc.ui.iufo.dataexchange.MultiSheetImportUtil;
import nc.ui.iufo.dataexchange.RepDataExport;
import nc.ui.iufo.dataexchange.RepDataWithCellsModelExport;
import nc.ui.iufo.dataexchange.TableDataToExcel;
import nc.ui.iufo.input.CSomeParam;
import nc.ui.iufo.input.InputActionUtil;
import nc.ui.iufo.input.ufoe.IUfoInputActionUtil;
import nc.ui.ufoc.dataexchange.UFOCMultiSheetImportUtil;
import nc.util.hbbb.HBVersionUtil;
import nc.util.hbbb.InputActionHandlerProxy;
import nc.util.hbbb.hbscheme.HBSchemeSrvUtils;
import nc.util.hbbb.reportcheck.HBSchemeCheckRunUtil;
import nc.util.hbbb.workdraft.head.IProjectCellHead;
import nc.util.hbbb.workdraft.pub.IWorkDraft;
import nc.util.hbbb.workdraft.pub.IWorkDraftFactory;
import nc.util.hbbb.workdraft.pub.ReportType;
import nc.util.iufo.input.BalanceReportExportUtil;
import nc.util.iufo.pub.UfoException;
import nc.util.iufo.report.ReportDSUtil;
import nc.util.iufo.sysinit.UfobIndividualSettingUtil;
import nc.util.iufo.sysinit.UfobSysParamQueryUtil;
import nc.util.ufoc.unionproject.ProjectSrvUtils;
import nc.utils.iufo.TotalSrvUtils;
import nc.vo.bd.accessor.IBDData;
import nc.vo.hbbb.hbscheme.HBSchemeVO;
import nc.vo.hbbb.util.KeyWordPubUtil;
import nc.vo.iufo.balance.BalanceCondVO;
import nc.vo.iufo.commit.CommitStateEnum;
import nc.vo.iufo.commit.RepDataCommitVO;
import nc.vo.iufo.commit.TaskCommitVO;
import nc.vo.iufo.data.MeasureDataUtil;
import nc.vo.iufo.data.MeasurePubDataVO;
import nc.vo.iufo.data.RepDataVO;
import nc.vo.iufo.datasource.DataSourceVO;
import nc.vo.iufo.keydef.KeyGroupVO;
import nc.vo.iufo.keydef.KeyVO;
import nc.vo.iufo.measure.MeasureVO;
import nc.vo.iufo.total.TotalSchemeVO;
import nc.vo.iuforeport.rep.ReportVO;
import nc.vo.org.OrgVO;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.ufoc.unionproject.ProjectVO;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;

import com.ufida.iufo.pub.tools.AppDebug;
import com.ufsoft.iufo.check.vo.CheckResultVO;
import com.ufsoft.iufo.fmtplugin.datastate.CellsModelOperator;
import com.ufsoft.iufo.fmtplugin.formatcore.IUfoContextKey;
import com.ufsoft.iufo.fmtplugin.formatcore.UfoContextVO;
import com.ufsoft.iufo.fmtplugin.service.ReportFormatSrv;
import com.ufsoft.iufo.func.excel.text.ImpExpFileNameUtil;
import com.ufsoft.iufo.inputplugin.biz.FontFactory;
import com.ufsoft.iufo.inputplugin.biz.data.ImportExcelDataBizUtil;
import com.ufsoft.iufo.inputplugin.biz.file.ChooseRepData;
import com.ufsoft.iufo.inputplugin.biz.file.MenuStateData;
import com.ufsoft.iufo.report.propertyoperate.UFOFormulaEditControl;
import com.ufsoft.iuforeport.repdatainput.LoginEnvVO;
import com.ufsoft.iuforeport.repdatainput.RepDataOperResultVO;
import com.ufsoft.iuforeport.repdatainput.TableInputActionHandler;
import com.ufsoft.iuforeport.repdatainput.TableInputHandlerHelper;
import com.ufsoft.iuforeport.tableinput.applet.DataSourceInfo;
import com.ufsoft.iuforeport.tableinput.applet.IRepDataParam;
import com.ufsoft.iuforeport.tableinput.applet.TableInputException;
import com.ufsoft.report.IufoFormat;
import com.ufsoft.table.Cell;
import com.ufsoft.table.CellPosition;
import com.ufsoft.table.CellsModel;
import com.ufsoft.table.format.CellFont;
import com.ufsoft.table.format.ICellFont;
import com.ufsoft.table.format.IFormat;


public class HBBBTableInputActionHandler extends TableInputActionHandler/*extends IUfoTableInputActionHandler*/ implements IAdjustRepQueryTypeConst{

	private UfoContextVO context = null;
	
	/**
	 * �ϲ��������뱨�����ݣ�����У��
	 */
	@Override
	public RepDataOperResultVO innerImportExcelData(IRepDataParam param,LoginEnvVO loginEnv,List<Object[]> listImportInfos,boolean isAutoCalc) throws Exception{
		
		if(HBRepSaveValid.getHBStatusVoIsLock(param.getTaskPK(), param.getAloneID())){
			throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830005-0313")/*@res "�ϲ����豻�������޷�����"*/);
		}
		
		UfoContextVO context=TableInputHandlerHelper.getContextVO(param,loginEnv);
		String strTaskPK =param.getTaskPK();
        DataSourceVO dataSource = loginEnv.getDataSource();
        MeasurePubDataVO pubdataVo = context.getPubDataVO();

        //����Ի��������Ƿ��Զ�����ѡ��˴���ʱ����Ϊ�Զ����� chxw 2007-09-26
//        MultiSheetImportUtil importUtil = ImportExcelDataBizUtil.getImportUtilBase(param.getReportPK(),null, dataSource, pubdataVo,param.getRepOrgPK(), param.getRepMngStructPK(),param.getCurGroupPK(),isAutoCalc, loginEnv.getCurLoginDate());
        MultiSheetImportUtil importUtil = getImportUtilBase(strTaskPK, param.getReportPK(),null, dataSource, pubdataVo,param.getRepOrgPK(),param.getRepMngStructPK(), param.getCurGroupPK(),isAutoCalc, loginEnv.getCurLoginDate());
        
        //������Excel׼��������Ϣ(CellsModel),���뵽���ݿ�
        boolean isNeedSave = true;
        ImportExcelDataBizUtil.processImportData(importUtil, listImportInfos, isNeedSave);

        ReportFormatSrv repFormatSrv=new ReportFormatSrv(context,true);
		CellsModel cellsModel=repFormatSrv.getCellsModel();

		RepDataOperResultVO result=new RepDataOperResultVO();
		result.setCellsModel(cellsModel);

		return result;
	}

	public static MultiSheetImportUtil getImportUtilBase(String strHBSchemePK, String strRepPK, String strUserPK, DataSourceVO dataSource, MeasurePubDataVO pubdataVo, String strOrgPK, String strRmsPK, String strGroupPK, boolean bAutoCalc, String strLoginDate) {
		return new UFOCMultiSheetImportUtil(strHBSchemePK, strRepPK, null, null, null, pubdataVo, strUserPK, dataSource, strOrgPK, strRmsPK, strGroupPK, bAutoCalc, strLoginDate);
	}
	  
	/**
	 * �������
	 *
	 * @create by liuchuna at 2010-6-30,����02:43:06
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public CheckResultVO[] checkTask(Object param) throws Exception{
		Object[] params=(Object[])param;
		return HBSchemeCheckRunUtil.doCheckInTask((IRepDataParam)params[0],(LoginEnvVO)params[1], true);
	}

	/**
	 * �������
	 *
	 * @create by liuchuna at 2010-6-30,����02:43:30
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public CheckResultVO checkReport(Object param) throws Exception{
		Object[] params=(Object[])param;
		return HBSchemeCheckRunUtil.doCheckInRep((IRepDataParam)params[0],(LoginEnvVO)params[1],(CellsModel)params[2],(Boolean)params[3], null);
	}

	/**
	 * ����¼�
	 *
	 * @create by liuchuna at 2010-6-30,����03:00:06
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public CheckResultVO[] checkSubReport(Object param) throws Exception{
//		Object[] params = (Object[]) param;
//		return HBSchemeCheckRunUtil.doCheckSubReport((MeasurePubDataVO)params[0],(CheckConVO)params[1],(IRepDataParam)params[2],(LoginEnvVO)params[3],(String)params[4]);
		throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830001-0503")/*@res "��֧�ֵĲ���"*/);
	}

	/**
	 * ��������¼�
	 *
	 * @create by liuchuna at 2010-6-30,����04:42:24
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public CheckResultVO[] checkSubTask(Object param) throws Exception{
//		Object[] params = (Object[]) param;
//		return HBSchemeCheckRunUtil.doCheckSubTask((MeasurePubDataVO)params[0],(CheckConVO)params[1],(IRepDataParam)params[2],(LoginEnvVO)params[3],(String)params[4]);
		throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830001-0503")/*@res "��֧�ֵĲ���"*/);
	}

	/**
	 * ��˽����ѯ
	 *
	 * @create by liuchuna at 2010-7-2,����11:38:28
	 *
	 * @param param
	 * @return
	 * @throws TableInputException
	 */
	public CheckResultVO[] queryCheckResult(Object param) throws TableInputException{
//		Object[] params = (Object[]) param;
//		return TaskCheckRunUtil.queryCheckResult((CheckConVO)params[0]);
		return null;
	}

	public RepDataOperResultVO innerOpenRepDatanotUseTask(IRepDataParam param,LoginEnvVO loginEnv,String strBalCondPK,IWorkDraft workdraft,MeasureVO measurevo,int dataCenterType) throws Exception{
		//�ж��Ƿ�ĩ����֯���ϲ��ͺϲ��������Ĳ��ܴ�ĩ����֯�ı�����
		String pk_org = param.getPubData().getUnitPK();
		String pk_hbrepstru = param.getRepMngStructPK();
		if (workdraft.getReporttype().equals(ReportType.HB) && pk_org != null && pk_hbrepstru != null && HBRepStruUtil.isLeafButNotBalanceMember(pk_org, pk_hbrepstru)) {
			throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830003-0096"));//"��ѡ���ĩ����֯��"
		}
		
		if (workdraft.getReporttype().equals(ReportType.HB_ADJ) && pk_org != null && pk_hbrepstru != null && HBRepStruUtil.isLeafMember(pk_org, pk_hbrepstru)){
			 throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830003-0096"));//"��ѡ���ĩ����֯��"
		}

		int iRepDataAuthType=RIGHT_DATA_READ;
		ReportCache repCache = UFOCacheManager.getSingleton().getReportCache();
		ReportVO repvo=repCache.getByPK(param.getReportPK());
		//TODO: ��������Ȩ��
		if(null!=repvo &&   null!=repvo.getDataauthflag() && repvo.getDataauthflag().booleanValue()){
			iRepDataAuthType = InputActionHandlerProxy.getRepDataRight(param);
			if(iRepDataAuthType == IUfoContextKey.RIGHT_DATA_NULL)
	           throw new Exception(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830001-0345")/*@res "�޲鿴��ǰ����������Ȩ��"*/);
		}

		MeasurePubDataVO pubData=param.getPubData();
        UfoContextVO context=TableInputHandlerHelper.getContextVO(param,loginEnv);
        CellsModel cellsModel=null;
        if (strBalCondPK==null || strBalCondPK.equals(BalanceCondVO.NON_SW_DATA_COND_PK)){
        	ReportFormatSrv repFormatSrv=new ReportFormatSrv(context,true);
        	cellsModel=repFormatSrv.getCellsModel();
        	if(workdraft.getReporttype().equals(ReportType.SEP_ADJ)){
        		cellsModel.setDirty(true);
        	}
        }else{
        	BalanceCondVO balanceCond=BalanceBO_Client.loadBalanceCondByPK(strBalCondPK);
        	RepDataVO repData=BalanceBO_Client.doSwBalance(pubData, balanceCond,param.getReportPK(), param.getRepMngStructPK());
        	cellsModel=CellsModelOperator.getFormatModelByPK(context);
        	cellsModel=CellsModelOperator.doGetDataModelFromRepDataVO(cellsModel, repData, context);
        	BalanceReportExportUtil.processBalanceRepCellsModel(new ReportFormatSrv(context,cellsModel),false,balanceCond);
            //weixl
        	pubData.setVer(0);
            pubData.setAloneID(MeasureDataUtil.getAloneID(pubData));
        }

		RepDataOperResultVO result=new RepDataOperResultVO();
		result.setCellsModel(cellsModel);
		MenuStateData menuStateData = getMenuStateData(workdraft,pubData,context, param, loginEnv, iRepDataAuthType, dataCenterType);
//		if(workdraft.getReporttype().equals(ReportType.SEP_ADJ)||workdraft.getReporttype().equals(ReportType.HB_ADJ)||workdraft.getReporttype().equals(ReportType.CONVERT)
//				||workdraft.getReporttype().equals(ReportType.HB)){
//
//			if(isSchemeCommit(pubData, param.getTaskPK())) {
//				menuStateData.setRepCanModify(false);
//				menuStateData.setM_bCanInput(false);
//			}
//			else {
//				menuStateData.setRepCanModify(true);
//			}
//
//    	}
		result.setMenuState(menuStateData);
		if(measurevo!=null){
			//����ָ���������ñ�����ɫ
			CellPosition measurePosByPK = CellsModelOperator.getMeasureModel(cellsModel).getMeasurePosByPK(measurevo.getCode());
			if(measurePosByPK!=null){
				Cell cell = cellsModel.getCell(measurePosByPK);
				IufoFormat format = (IufoFormat) cell.getFormat();
				CellFont font = (CellFont) format.getFont();
				ICellFont instance = CellFont.getInstance(font.getFontname(), font.getFontstyle(), font.getFontsize(), Color.GRAY, font.getForegroundColor());
				IFormat instance2 = IufoFormat.getInstance(format.getDataFormat(), instance, format.getAlign(), format.getLines());
				cell.setFormat(instance2);
			}
		}
//		boolean bIsCanInput = UfoEFormulaEditControl.isFormulaEdit(param.getReportPK(),param.getTaskPK());
		//TODO:���й�ʽ�ĵ�Ԫ���Ƿ������༭��1����ȡ��Ԫ��ʽ���ԣ�2����ȡ�������壻3����ȡȫ������
		boolean bIsCanInput = UFOFormulaEditControl.isFormulaEdit(param.getReportPK());
		result.setFmlCanInput(bIsCanInput);

		MenuStateData menuData=result.getMenuState();
		processMenuState(menuData,param,loginEnv,workdraft);
		cellsModel.setDirty(false);

		return result;
	}

	/**
	 * �õ������˵�״̬������ ���ݸò˵�״̬�������ǰ̨�����˵���Ĳ���״̬�����Ƿ�ɼ����Ƿ�����Լ�����Ȩ��
	 * ���������㰴ť���������⣨���������༭������������ʱ��������㰴ť���ã�
	 */
	private MenuStateData getMenuStateData(IWorkDraft workdraft,MeasurePubDataVO pubData,UfoContextVO context,
			IRepDataParam param, LoginEnvVO loginEnv, int nDataRight, int dataCenterType)
			throws TableInputException{
		MenuStateData menuStateData = new MenuStateData();
		DataSourceInfo dsInfo = param.getDSInfo();
		boolean bRepCanModify = false;
		if (context.getPubDataVO() != null){
			KeyGroupVO keyGroupVO = context.getPubDataVO().getKeyGroup();
			if (keyGroupVO != null){
				KeyVO[] keyVOs = keyGroupVO.getKeys();
				for (int i = 0; i < keyVOs.length; i++){
					if (KeyVO.isUnitKeyVO(keyVOs[i]))
						menuStateData.setHasUnitKey(true);
					else{
						if (keyVOs[i].isTimeKeyVO()|| keyVOs[i].isAccPeriodKey())
							menuStateData.setHasTimeKey(true);
					}
				}
			}

			try{
				if (context.getPubDataVO().getVer() == 350)
					menuStateData.setCanTraceData(true);
				else if (dsInfo != null && dsInfo.getDSID() != null&& (context.getPubDataVO().getVer() == 0)){// context.getPubDataVO().getVer()==HBBBSysParaUtil.VER_HBBB)){
					DataSourceVO dataSource = ReportDSUtil.findByID(dsInfo.getDSID());
					if (dataSource.getDs_type() == DataSourceVO.TYPENC2){
						menuStateData.setCanTraceData(true);
					}
				}

				// modified by litfb@20120516 ���𱨱����������ϲ���������������������������޸�
				// ֻ�кϲ��������ĵĺϲ�����ҳǩ�����޸�
				//@editted by zhoushuang at 2015.3.12  �������-ɽ����Ҷר��-�{���������޸�
				//SEP_ADJUST  0,HB_ADJUST  1,HB,CONVERT  2; 
//				if (DataCenterType.HB.equals(dataCenterType) && ReportType.HB.equals(workdraft.getReporttype())) {
				if ((dataCenterType == 0 && ReportType.SEP_ADJ.equals(workdraft.getReporttype()))
						|| (dataCenterType == 1 && ReportType.HB_ADJ.equals(workdraft.getReporttype()))
						|| (dataCenterType == 2 && ReportType.HB.equals(workdraft.getReporttype()))) {
					if (isSchemeCommit(pubData, param.getTaskPK())) {
						menuStateData.setM_bCanInput(false);
						bRepCanModify = false;
					} else {
						bRepCanModify = true;
					}
				}
			}
			catch (Exception e){
				AppDebug.debug(e);
			}
		}
		menuStateData.setRepCanModify(bRepCanModify);
		String strReportPK = param.getReportPK();
		menuStateData.setHasRepCheckFormula(InputActionUtil.isExistRepCheckFormulas(strReportPK));
		if (context.getPubDataVO() != null)
			menuStateData.setDataVer(context.getPubDataVO().getVer());
		if (!bRepCanModify){
			// ���ݲ˵���Ϣ
			menuStateData.setCanCal(false);
			menuStateData.setCanAreaCal(false);
			// �����˵�״̬Ϊȱʡ����ֵ
			return menuStateData;
		}
		else{
			// ���ݲ˵���Ϣ
			menuStateData.setCanAreaCal(true);
			menuStateData.setAutoCheck(InputActionUtil.isAutoCheck());

			// ��λ�����ܡ��ϲ������汾���ܼ��㣬ֻ�ܽ����������
			if(context.getPubDataVO() == null) {
				return menuStateData;
			}
			int iDataVer = context.getPubDataVO().getVer();
			if (iDataVer == 510 || iDataVer == 350 || iDataVer >= 1000){
				menuStateData.setCanCal(false);
			}
		}
		return menuStateData;
	}


	/**
	 * ��Ҫ�������滻��IUfoTableInputAction���openRepData����
	 * �滻���ɣ�
	 * ����������õĻ�������ʹ��ActionHandler.execWithZip������
	 * ��Ϊ�÷�����Ҫ������ΪҪ����ActionHandler.execWithZip�ĵ��ö����ڵ�
	 * ���ǵ�IUfoTableInputAction������openRepData�����ڽ�������Ĳ�����ʱ��
	 * �����Ĳ������������Ͷ���IUFO�Ǳߣ������Ļ�����HBBB����봫���µĲ������ͻ��߸����ͻ�����ѡ�
	 *
	 * ��������Ҫ���ifreetable �Ļ������ǽ������IUfoTableInputAction���openRepData����
	 * @date 20110601
	 * @author liyra
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked" })
	public RepDataOperResultVO proxyopenRepData(Object param) throws Exception{

		try{
			Object[] params=(Object[])param;
			IRepDataParam repDataParam=(IRepDataParam)params[0];

			boolean bFreeTotal = (Boolean) params[4];
			//�����֯Ϊ��֯���Թ��� :û�е�λ�ؼ���ʱ������ͨ����λ�ؼ����жϡ�
//			if (StringUtil.isEmptyWithTrim(OrgUtil.getOrgName(repDataParam.getPubData().getUnitPK())))
			if(bFreeTotal)
			{
				LoginEnvVO loginEnv=(LoginEnvVO)params[1];
				ArrayList<String> lstTotalReportOrgPK=(params!=null&&params.length>3)?(ArrayList<String>)params[3]:null;
				TotalSchemeVO totalScheme=new TotalSchemeVO();
				totalScheme.setOrg_type(TotalSchemeVO.TYPE_CUSTOMER);
				totalScheme.setOrg_content(lstTotalReportOrgPK);
				totalScheme.setPk_org(repDataParam.getRepOrgPK());
				RepDataOperResultVO result= TotalSrvUtils.createFreeTotalResults(repDataParam.getPubData(), totalScheme,repDataParam.getReportPK(), null);
				UfoContextVO context=TableInputHandlerHelper.getContextVO(repDataParam,loginEnv);
				context.setAttribute(MEASURE_PUB_DATA_VO, repDataParam.getPubData());
				MenuStateData  menuState=TableInputHandlerHelper.getMenuStateData(context, repDataParam, loginEnv, UfoContextVO.RIGHT_DATA_WRITE);
				menuState.setCanCommit(false);
				menuState.setCanRequestCancelCommit(false);
				menuState.setCanAreaCal(false);
				menuState.setCanExcelImp(false);
				menuState.setCanSW(false);

				return result;
			}else
			{
				try{
//					Object[] params=(Object[])param;
					return innerOpenRepData((IRepDataParam)params[0],(LoginEnvVO)params[1],(String)params[2],(IWorkDraft)params[5],(MeasureVO)params[6],(Integer)params[7]);
				}catch(Exception e){
					AppDebug.debug(e);
					throw e;
				}
			}

		}catch(Exception e){
			AppDebug.debug(e);
			throw e;
		}


	}


	public RepDataOperResultVO innerOpenRepData(IRepDataParam param,LoginEnvVO loginEnv,String strBalCondPK,IWorkDraft workdraft,MeasureVO measurevo,int dataCenterType) throws Exception{
		String strRepPK=param.getReportPK();
		UfoContextVO context=TableInputHandlerHelper.getContextVO(param,loginEnv);
		//ȡ�ò鿴���ͼ������ı���PK
		MeasurePubDataVO pubData=param.getPubData();
//		int iSepIndex=strRepPK.indexOf(SEP_TYPE_FLAG);
//		String strType=strRepPK.substring(0,iSepIndex);
//		strRepPK=strRepPK.substring(iSepIndex+1);
		param.setReportPK(strRepPK);
		String pk_org = param.getPubData().getKeywordByPK(KeyVO.CORP_PK);
		if (pk_org!=null) {
			param.getPubData().setKeywordByPK(KeyVO.CORP_PK, pk_org.substring(0, 20));
		}
		HBSchemeVO hbScheme=HBSchemeSrvUtils.getHBSchemeByHBSchemeId(param.getTaskPK());
		setContext(context);
		if(workdraft.isdraft()){
			RepDataOperResultVO result=new RepDataOperResultVO();
			CellsModel cellsModel=loadDraftCellsModel(strRepPK, param,workdraft);

			result.setCellsModel(cellsModel);
			return result;
		}else{
			if(workdraft.getReporttype().equals(ReportType.HB)){
				pubData.setVer(hbScheme.getVersion());
			}else if(workdraft.getReporttype().equals(ReportType.SEP_ADJ)){
				int ver = IWorkDraftFactory.getAdjVersion(hbScheme);
				if(ver == HBVersionUtil.MAXVERISON_ADJ) {
					throw new BusinessException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830005-0314")/*@res "δ�ҵ���Ӧ�ĵ���������"*/);
				}
				pubData.setVer(ver);
			}else if(workdraft.getReporttype().equals(ReportType.HB_CONTRAST)){
				pubData.setVer(HBVersionUtil.getHBContrastByHBSchemeVO(hbScheme));
			}else if(workdraft.getReporttype().equals(ReportType.HBDIFF)){
				pubData.setVer(HBVersionUtil.getDiffByHBSchemeVO(hbScheme));
			}else{
				pubData.setVer(workdraft.getVersion(hbScheme,0));
			}

			pubData.setAloneID(null);
			pubData.setAloneID(MeasurePubDataBO_Client.getAloneID(pubData));
			param.setAloneID(pubData.getAloneID());
			
			return innerOpenRepDatanotUseTask(param, loginEnv, strBalCondPK,workdraft,measurevo,dataCenterType);
		}

	}



//	/**
//	 * TODO:�����׸塢����׸�����ݼ��ش�ʵ��
//	 * TODO:û�п��ǵ�����׸���������������׸�˴���������Ҫ�Ķ�
//	 * TODO:�ع�����
//	 * ���ش򿪵׸�ʱ���õ���CellsModel
//	 * @param strRepPK:����PK
//	 * @param pubData���ؼ�������
//	 * @param strModelPK��ģ��PK�����Ϊ�գ���ʾֱ�����б���ʽ��
//	 * @param bHBRep���Ǻϲ��������Ǹ��𱨱�
//	 * @return
//	 */
//	@SuppressWarnings("unchecked")
	public CellsModel loadDraftCellsModel(String strRepPK,IRepDataParam param,IWorkDraft workdraft) throws Exception{

		List<Cell[]> lstAll = new ArrayList<Cell[]>();
		return CellsModel.getInstance(lstAll.toArray(new Object[0][0]), true);
	}
//	/**
//	 * ���ݵ׸����ݵõ�cells
//	 * @param datas
//	 * @return
//	 */
//	private Cell[][] genDataCell(int iStartRow,Object[][] datas){
//		int rowSize = datas.length;
//		int colSize = datas[0].length;
//		Cell[][] cells = new Cell[rowSize][colSize];
//		for(int i = 0;i < rowSize; i++){
//			for(int j = 0;j < colSize;j++){
//				Object object = datas[i][j];
//				Cell cell = new Cell();
//				cell.setRow(i+iStartRow);
//				cell.setCol(j);
//				if(object!=null)
//					cell.setValue( object.toString());
//				cell.setFormat(IufoFormat.getInstance());
//				cells[i][j] = cell;
//			}
//		}
//		return cells;
//	}

	public  String  getAloneID(String pk_org,String pk_report ,Map<String, String> keyMap,int verSion) throws BusinessException{
		String result="";
		MeasurePubDataVO pubdata  = new MeasurePubDataVO();
		ReportCache repCache = UFOCacheManager.getSingleton().getReportCache();

		ReportVO repVo = repCache.getByPK(pk_report);
		pubdata.setKType(repVo.getPk_key_comb());
		KeyGroupVO keygroupVo = UFOCacheManager.getSingleton().getKeyGroupCache().getByPK(repVo.getPk_key_comb());
		pubdata.setKeyGroup(keygroupVo);
		KeyVO[] keyvos=keygroupVo.getKeys();
		if(null!=keyvos && null!=keyMap && keyvos.length==keyMap.size()){
			String[] keys=new String[keyMap.size()];
			keyMap.keySet().toArray(keys);
			if(null!=keys && keys.length>0){
				for(String key:keys){
						pubdata.setKeywordByPK(key, keyMap.get(key));
				}
			}
			pubdata.setKeywordByPK(KeyVO.CORP_PK,pk_org);
			pubdata.setVer(verSion);
		    try {
				result=MeasurePubDataBO_Client.getAloneID(pubdata);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				nc.bs.logging.Logger.error(e.getMessage(), e);
				throw new BusinessException(e);
			}
		}

		return result;
	}

//	private Object[] getUnionOrgs(IRepDataParam param) {
//		//ȡ�øñ�����֯��ϵ��,�ò�ѯ��λ��������λ(�����Լ�)
//		String repMngStructPK = param.getRepMngStructPK();//������֯��ϵ
//		String repOrgPK = param.getRepOrgPK();//��ǰ��֯
//		Object[] unitOrgs =null;
//		StringBuffer strBuffer = new StringBuffer();
//		strBuffer.append("select  a.pk_org from " +
//				"(  select  org_reportmanastru.pk_reportmanastru , org_rmsmember.pk_org, org_rmsmember.innercode as icode " +
//				" from " +
//				" org_rmsmember " +
//				" inner join  " +
//				" org_reportmanastru   on " +
//				" org_rmsmember.pk_rms = org_reportmanastru.pk_reportmanastru " +
//				" where " +
//				" org_reportmanastru.pk_reportmanastru = ? ) as a, " +
//				" ( select   org_rmsmember.innercode as code  from  org_rmsmember " +
//				" where " +
//				" pk_rms    = ? " +
//				" and pk_org= ? " +
//				" ) as b " +
//				" where  " +
//				" a.icode like b.code || '%'");
//		SQLParameter para = new SQLParameter();
//		para.addParam(repMngStructPK);
//		para.addParam(repMngStructPK);
//		para.addParam(repOrgPK);
//		try {
//			@SuppressWarnings("unchecked")
//			List<Object> result = (List<Object>) NCLocator.getInstance().lookup(IUAPQueryBS.class).executeQuery(strBuffer.toString(), para, new ColumnListProcessor());
//			unitOrgs = result.toArray(new Object[0]);
//		} catch (BusinessException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return unitOrgs;
//	}

	/**
	 * �õ��ؼ���cell
	 * @param iStartRow
	 * @param pubdata
	 * @param iColSize
	 * @return
	 */
	protected Cell[] getKeywordCell(int iStartRow,IRepDataParam param) throws BusinessException{
		List<Cell> list = new ArrayList<Cell>();
		String[] keyword = getKeyword(param.getPubData());
		int j =0;
		for (int i = 0; i < keyword.length; i++) {
			Cell cell = new Cell();
			cell.setValue(keyword[i]);
			cell.setRow(iStartRow);
			cell.setCol(j);
			cell.setFormat(IProjectCellHead.keywordformat);
			list.add(cell);
			if(i>0){
				list.add(null);
				j++;
			}
			j++;
		}
		return list.toArray(new Cell[0]);

	}

	/**
	 * �õ��ؼ�����ֵ�����:��ʾ˳��λ/ʱ��/���ּ������ؼ���
	 * @param aloneId
	 * @return
	 */
	protected String[] getKeyword(MeasurePubDataVO pubdata) throws BusinessException{
		List<String> unitOrTime  = new ArrayList<String>();
		List<String> otherKey  = new ArrayList<String>();
		KeyVO[] keys = pubdata.getKeyGroup().getKeys();
		for(int i=0;i<keys.length;i++){
			String name = KeyWordPubUtil.getMulName(keys[i]);
			String keywordPK = keys[i].getPk_keyword();
			String value = pubdata.getKeywordByPK(keywordPK);

			if(keywordPK.equals(KeyVO.CORP_PK)){
				value = getUnitCodeNameByPK(value);
				unitOrTime.add(name+":"+value);
			}else if(KeyVO.isTTimeKey(keywordPK)){
				unitOrTime.add(name+":"+value);
			}else if(keywordPK.equals(KeyVO.COIN_PK)){
				value = getCurrTypeName(value);
				otherKey.add(name+":"+value);
			}else{
				//�Զ���ؼ���,��������PK
				if(keys[i].getRef_pk() != null){
					IGeneralAccessor accessor = GeneralAccessorFactory.getAccessor(keys[i].getRef_pk());
					if(accessor != null){
						IBDData data = accessor.getDocByPk(value);
						if(data != null)
							value = data.getName().toString();
					}
				}
				otherKey.add(name+":"+value);
			}
		}
		unitOrTime.addAll(otherKey);
		return unitOrTime.toArray(new String[unitOrTime.size()]);
	}


	public String getCurrTypeName(String pk_currtype){
		String result="";
	    try {
			result=	CurrtypeQuery.getInstance().getCurrtypeName(pk_currtype);
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			nc.bs.logging.Logger.error(e.getMessage(), e);
		}
		return result;
	}

	/**
	 *
	 * ͨ��PK�õ���λ�ı��������
	 * @param strUnitPK
	 * @return
	 */

	public String getUnitCodeNameByPK(String strUnitPK) throws BusinessException{
		String strUnit = null;
		if(strUnitPK==null)  return strUnit;
		OrgVO org = NCLocator.getInstance().lookup(IOrgUnitQryService.class).getOrg(strUnitPK);
		if(org!=null)
			strUnit = "("+org.getCode()+")" + MultiLangTextUtil.getCurLangText(org);

		return strUnit;
	}




	protected void processMenuState(MenuStateData menuData,IRepDataParam param,LoginEnvVO loginEnv,IWorkDraft workdraft) throws Exception{
		MeasurePubDataVO pubData=param.getPubData();
		if (menuData!=null){
			HBSchemeVO hbschemevo = HBSchemeSrvUtils.getHBSchemeByHBSchemeId(param.getTaskPK());
			MenuStateData taskCommitState=getTaskMenuState(pubData, hbschemevo,loginEnv);;
//			menuData.setCommited(taskCommitState.isCommited());
			menuData.setCanCommit(taskCommitState.isCanCommit());
			menuData.setCanRequestCancelCommit(taskCommitState.isCanRequestCancelCommit());

			String aloneid = pubData.getAloneID();
			// �ֲ�ʽ������Դ��� qugx
			// �ϲ���������û���ϱ���Ϣ�����Ե��������֮�������ֲ�ʽ�����ı�Ҳ�ܱ༭��
			// �޸��߼������Ǻϲ����������鿴���Ӧ�ĺϲ������Ƿ��Ƿֲ�ʽ��������ݣ�������Ҫ -- jiaah
			if(workdraft != null && workdraft.getReporttype().equals(ReportType.HB_CONTRAST)){
				MeasurePubDataVO clone = (MeasurePubDataVO) pubData.clone();
				clone.setVer(hbschemevo.getVersion());
				clone.setAloneID(null);
				aloneid = MeasurePubDataBO_Client.getAloneID(clone);//��Ӧ�ĺϲ�������aloneid
			}
			
			ICommitQueryService commitQuerySrv = NCLocator.getInstance().lookup(ICommitQueryService.class);
			RepDataCommitVO[] repDataCommitVOs = commitQuerySrv.getReportCommitState(new String[]{aloneid},param.getReportPK());
			if (repDataCommitVOs != null && repDataCommitVOs.length > 0){
				menuData.setDisTrans(repDataCommitVOs[0].getDataorigin() == null? false : true);
			}
		}
	}

	public MenuStateData getTaskMenuState(MeasurePubDataVO pubData,HBSchemeVO hbschemevo,LoginEnvVO loginEnv) throws Exception{
		MenuStateData menuData=new MenuStateData();

//		String aloneID = pubData.getAloneID();
//		String pk_hbscheme = hbschemevo.getPk_hbscheme();
//		String condition = "alone_id='"+aloneID+"' and pk_hbscheme='" + pk_hbscheme+"'";
//		List<TaskCommitVO> lstTaskCommit = (List<TaskCommitVO>)NCLocator.getInstance().lookup(IUAPQueryBS.class).retrieveByClause(TaskCommitVO.class, condition);
		if(isSchemeCommit(pubData, hbschemevo.getPk_hbscheme())) {
			menuData.setCommited(true);
			menuData.setCanCommit(false);
			menuData.setCanRequestCancelCommit(true);
		}else{
			menuData.setCommited(false);
			menuData.setCanCommit(true);
			menuData.setCanRequestCancelCommit(false);
		}
		return menuData;
	}

	public static boolean isSchemeCommit(MeasurePubDataVO pubData,String pk_hbscheme) throws BusinessException {
		String aloneID = pubData.getAloneID();
		return isSchemeCommit(aloneID, pk_hbscheme);
	}
	public static boolean isSchemeCommit(String aloneID,String pk_hbscheme) throws BusinessException {
		String condition = "alone_id='"+aloneID+"' and pk_task='" + pk_hbscheme+"'";
		@SuppressWarnings("unchecked")
		List<TaskCommitVO> lstTaskCommit = (List<TaskCommitVO>)NCLocator.getInstance().lookup(IUAPQueryBS.class).retrieveByClause(TaskCommitVO.class, condition);
		return (lstTaskCommit!=null && lstTaskCommit.size()>0 && lstTaskCommit.get(0).getCommit_state() != null
				&& lstTaskCommit.get(0).getCommit_state().intValue()==CommitStateEnum.STATE_COMMITED.getIntValue());
	}

	public static boolean isRepCommit(String aloneID,String pk_report) throws BusinessException {
		SQLParameter params = new SQLParameter();
		String condition = "alone_id =? and pk_report =?";
		params.addParam(aloneID);
		params.addParam(pk_report);
		@SuppressWarnings("unchecked")
		List<RepDataCommitVO> lstRepCommit = (List<RepDataCommitVO>)NCLocator.getInstance().lookup(IUAPQueryBS.class).
			retrieveByClause(RepDataCommitVO.class,condition,new String[]{RepDataCommitVO.COMMIT_STATE},params);
		return (lstRepCommit!=null && lstRepCommit.size()>0 && lstRepCommit.get(0).getCommit_state() != null
				&& lstRepCommit.get(0).getCommit_state().intValue() == CommitStateEnum.STATE_COMMITED.getIntValue());
	}


	@Override
	protected RepDataOperResultVO innerDoSaveRepData(CellsModel cellsModel,UfoContextVO context,IRepDataParam param) throws Exception{
		if (IUfoInputActionUtil.isRepCommit(param.getReportPK(), param.getAloneID())){
			throw new UfoException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("1820001_0","01820001-1146")/*@res "���������Ѿ��ϱ����޷�����"*/);
		}

		//�жϺϲ��ڵ��Ƿ��Ѿ��ڼ��̨����
		if(HBRepSaveValid.getHBStatusVoIsLock(param.getTaskPK(),param.getAloneID()))
			throw new UfoException(nc.vo.ml.NCLangRes4VoTransl.getNCLangRes().getStrByID("pub_0","01830005-0315")/*@res "�ϲ����̨�������������޷�����"*/);

		CellsModel dataModel = cellsModel;
        ReportFormatSrv reportFormatSrv = new ReportFormatSrv(context,dataModel);
        reportFormatSrv.saveReportData();

        RepDataOperResultVO resultVO=new RepDataOperResultVO();
        resultVO.setCellsModel(cellsModel);
        resultVO.setOperSuccess(true);

        // �Ƿ��Զ��������
        UFBoolean ufboolean = UfobIndividualSettingUtil.getAutoCheck();
        boolean autoCheck = (ufboolean == null && UfobSysParamQueryUtil.getAutoCheck()) || (ufboolean != null &&  ufboolean.booleanValue());
		//����ϵͳ�������ý����Զ����(���������˹�ʽ�Ļ�)
        if(autoCheck && InputActionUtil.isExistRepCheckFormulas(param.getReportPK())){
        	boolean warnPass = true;//����г��־�������ͨ��
            //���б�����˲�������˽�� ���������������ģ���е���˽��״̬��
        	CheckResultVO result = TableInputHandlerHelper.doCheckInRep(context, cellsModel, true,warnPass);
        	MeasurePubDataVO pub = param.getPubData();
        	KeyGroupVO keyGroupVO = pub.getKeyGroup();
        	String pk_org = "";
        	for (int i = 0; i < keyGroupVO.getKeys().length; i++) {
        		KeyVO key = keyGroupVO.getKeys()[i];
        		if(KeyVO.isUnitKeyVO(key)){
        			pk_org = pub.getKeywords()[i];
        		}
			}
        	result.setOrgId(pk_org);
        	resultVO.setCheckResult(result);
        }

        //����iufo_rep_commit��
        ICommitManageService commitSrv = NCLocator.getInstance().lookup(ICommitManageService.class);
        commitSrv.addRepInputSate(param.getTaskPK(), param.getAloneID(), param.getReportPK(), param.getOperUserPK(), true, param.getLastCalcTime());

        //��Ŀͬ��
        doSynProject(param);
		return resultVO;
	}

	private void doSynProject(IRepDataParam param) throws Exception{
        Map<String, ProjectVO> mappings = ProjectSrvUtils.getMeasureMappings(new String[] {param.getReportPK()});
        ProjectSynchronize syn = new ProjectSynchronize();
        syn.setAryRepIDs(new String[] {param.getReportPK()});
        syn.setDstPubdata(param.getPubData());
        syn.setMeasProMap(mappings);
        HBSchemeVO schemeVO = new HBSchemeVO();
        schemeVO.setPk_hbscheme(param.getTaskPK());
        syn.setHbSchemeVo(schemeVO);
        syn.doSaveHBSynchronize();
	}

	/**
	 * �����ʱ����ݵ�ǰ�ĺϲ������ı���ƥ���ѡ����
	 * @author jiaah
	 */
	@Override
	public ChooseRepData[] innerLoadTableImportReps(IRepDataParam param) throws Exception{
		try{
			String pk_hbscheme = param.getTaskPK();
			ReportVO[] reports = HBSchemeSrvUtils.getReportVOByHBSchemeId(pk_hbscheme);
			return TableInputHandlerHelper.geneChooseRepDatas(reports);
		}finally{
		}
	}

	public UfoContextVO getContext() {
		return context;
	}

	public void setContext(UfoContextVO context) {
		this.context = context;
	}
	/**
	 * �����Ƿ���ʾ0ֵ�ֶ�
	 * 
	 * @creator tianjlc at 2015-3-18 ����5:01:58
	 * @param param
	 * @param loginEnv
	 * @param cellsModel
	 * @param sheetName
	 * @param filepath
	 * @param bShowZero
	 * @return
	 * @throws Exception
	 * @return byte[]
	 */
	public byte[] innerExport2ExcelWithShowZero(IRepDataParam param, MeasurePubDataVO newMesureDataVO,LoginEnvVO loginEnv, CellsModel cellsModel, String sheetName, String filepath,boolean bShowZero) throws Exception {
		String strAloneID4ExportExcel = newMesureDataVO.getAloneID();
		UfoContextVO context = TableInputHandlerHelper.getContextVO(param, loginEnv);
		RepDataWithCellsModelExport exportObj = new RepDataWithCellsModelExport(context, cellsModel,newMesureDataVO);

		String strReportPK4ExportExcel = param.getReportPK();
		CSomeParam cSomeParam = new CSomeParam();
		cSomeParam.setAloneId(strAloneID4ExportExcel);
		cSomeParam.setRepId(strReportPK4ExportExcel);
		cSomeParam.setUserID(param.getOperUserPK());
		MeasurePubDataVO pubData = param.getPubData();
		cSomeParam.setUnitId(pubData.getUnitPK());
		((RepDataExport) exportObj).setParam(cSomeParam);
		((RepDataExport) exportObj).setLoginDate(loginEnv.getCurLoginDate());
		// editor tianjlc 2015-03-18 ���õ���������Excel�ļ��Ƿ���ʾ0ֵ
		((RepDataExport) exportObj).setShowZero(bShowZero);

		Workbook workBook = null;
		if (ImpExpFileNameUtil.isExcel2003(filepath)) {
			workBook = new HSSFWorkbook();
		} else if (ImpExpFileNameUtil.isExcel2007(filepath)) {
			workBook = new org.apache.poi.xssf.streaming.SXSSFWorkbook(500);
		}
		FontFactory fontFactory = new FontFactory(workBook);
		if (StringUtils.isEmpty(sheetName)) {
			sheetName = "sheet1";
		}
		exportObj.setSheetName(sheetName);
		TableDataToExcel.translate(exportObj, workBook, fontFactory);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		workBook.write(outputStream);
		outputStream.flush();

		byte[] bytes = outputStream.toByteArray();
		outputStream.close();
		return bytes;
	}
	
	/**
	 * �����Ƿ���ʾ0ֵ�ֶ�
	 * 
	 * @creator tianjlc at 2015-3-19 ����8:39:40
	 * @param param
	 * @return
	 * @throws Exception
	 * @return byte[]
	 */
	public byte[] export2ExcelWithShowZero(Object param) throws Exception {
		try {
			Object[] params = (Object[]) param;
			return innerExport2ExcelWithShowZero((IRepDataParam) params[0],(MeasurePubDataVO)params[1],(LoginEnvVO) params[2], (CellsModel) params[3], (String) params[4], (String) params[5],(boolean)params[6]);
		} catch (Exception e) {
			AppDebug.debug(e);
			throw e;
		}
	}
}
package nccloud.pubimpl.platform.attachment;

public class FtpConstants {
	public static final  String REPLACE = "replace";
	public static final  String UP_LOAD = "upload";
}

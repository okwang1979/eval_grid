package nc.lightapp.framework.web.action.attachment;


public abstract interface IUploadAction
{
  public abstract Object doAction(AttachmentVO paramAttachmentVO);
}
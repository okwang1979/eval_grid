package nccloud.web.ct.saledaily.action;

public class TokenInfo{
	private String code;
	private String token;
	private Integer successflag;
	
	private String message;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Integer getSuccessflag() {
		return successflag;
	}

	public void setSuccessflag(Integer successflag) {
		this.successflag = successflag;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	
	
	
	

	
	
}
 
package test.vo.ct.saledaily.entity;

public class SaleParamCheckUtils {
	
	
	//test

}

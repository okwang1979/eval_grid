package nc.vo.ct.saledaily.entity;

import java.io.Serializable;

public class CtPuJsonVO implements Serializable{

}

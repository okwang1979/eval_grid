package nc.vo.ct.saledaily.entity;

/**
 * @author ��־ǿ
 * ú��Ժ�ӿڳ����ӿ�
 *
 */
public class SaleConst {
	
	
	
	private static String APP_USER = "KGJN";
	
	private  static String SECRE_KEY="OXpXfaLG5v0LZedTEi2F2WcnGQmPoi5n0m+srzE1kmE=";
	
	private static String IP_PORINT = "http://172.18.102.210:8888";

	public static String getAPP_USER() {
		return APP_USER;
	}

	public static String getSECRE_KEY() {
		return SECRE_KEY;
	}

	public static String getIP_PORINT() {
		return IP_PORINT;
	}
	
	

 
	
	
	

}
